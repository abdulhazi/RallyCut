package com.steve.rallycut

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File
import java.io.FileDescriptor
import java.nio.ByteBuffer

/** Gallery (Movies/RallyCut) helpers. */
object Gallery {
    fun createPending(context: Context, displayName: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/RallyCut")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        return context.contentResolver.insert(collection, values)
            ?: throw IllegalStateException("Could not create the file in Movies/RallyCut")
    }

    fun publish(context: Context, item: Uri) {
        val done = ContentValues()
        done.put(MediaStore.Video.Media.IS_PENDING, 0)
        context.contentResolver.update(item, done, null, null)
    }

    fun discard(context: Context, item: Uri) {
        try {
            context.contentResolver.delete(item, null, null)
        } catch (_: Exception) {
        }
    }

    fun sizeOf(context: Context, item: Uri): Long = try {
        context.contentResolver.openFileDescriptor(item, "r")?.use { it.statSize } ?: -1L
    } catch (_: Exception) {
        -1L
    }

    /** Copies a finished file into Movies/RallyCut. Background thread. */
    fun copyIn(context: Context, file: File, displayName: String): Uri {
        val item = createPending(context, displayName)
        try {
            val out = context.contentResolver.openOutputStream(item)
                ?: throw IllegalStateException("Could not open the output file")
            out.use { o -> file.inputStream().use { it.copyTo(o, 1 shl 20) } }
            publish(context, item)
            return item
        } catch (e: Exception) {
            discard(context, item)
            throw e
        }
    }
}

/**
 * Joins clips by copying the compressed video/audio samples (no re-encoding): fast and lossless.
 * Each clip starts at the keyframe at or before its start, so it can begin up to ~1 s early.
 */
class FastExporter(private val context: Context) {
    @Volatile var cancelled = false

    private fun findTrack(ex: MediaExtractor, prefix: String): Int {
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(prefix)) return i
        }
        return -1
    }

    private fun intOr(f: MediaFormat, key: String, def: Int): Int {
        if (!f.containsKey(key)) return def
        return try {
            f.getInteger(key)
        } catch (_: Exception) {
            try {
                f.getFloat(key).toInt()
            } catch (_: Exception) {
                def
            }
        }
    }

    /** clipsMs: each = [startMs, endMs], in order. */
    fun export(uri: Uri, clipsMs: List<LongArray>, rotation: Int, out: FileDescriptor, progress: (Float) -> Unit) {
        val vEx = MediaExtractor()
        val aEx = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            vEx.setDataSource(context, uri, null)
            aEx.setDataSource(context, uri, null)
            val vt = findTrack(vEx, "video/")
            if (vt < 0) throw IllegalStateException("No video track")
            val at = findTrack(aEx, "audio/")
            vEx.selectTrack(vt)
            if (at >= 0) aEx.selectTrack(at)
            val vf = vEx.getTrackFormat(vt)
            val af = if (at >= 0) aEx.getTrackFormat(at) else null
            val m = MediaMuxer(out, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            val mv = m.addTrack(vf)
            val ma = if (af != null) m.addTrack(af) else -1
            if (rotation == 90 || rotation == 180 || rotation == 270) m.setOrientationHint(rotation)
            m.start()
            started = true

            val bufSize = maxOf(intOr(vf, MediaFormat.KEY_MAX_INPUT_SIZE, 0), if (af != null) intOr(af, MediaFormat.KEY_MAX_INPUT_SIZE, 0) else 0, 8 shl 20)
            val buf = ByteBuffer.allocateDirect(bufSize)
            val info = MediaCodec.BufferInfo()
            val fps = intOr(vf, MediaFormat.KEY_FRAME_RATE, 30).coerceIn(1, 480)
            val frameUs = 1_000_000L / fps
            val audioFrameUs = if (af != null) 1024L * 1_000_000L / intOr(af, MediaFormat.KEY_SAMPLE_RATE, 48000).coerceAtLeast(1) else 0L
            val totalUs = clipsMs.sumOf { (it[1] - it[0]) * 1000 }.coerceAtLeast(1)
            var doneUs = 0L
            var offset = 0L
            var lastVideoOut = -1L
            var lastAudioOut = -1L
            var lastReport = 0L

            for (clip in clipsMs) {
                val startUs = clip[0] * 1000
                val endUs = clip[1] * 1000
                vEx.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                val syncUs = vEx.sampleTime
                if (syncUs < 0) continue
                if (af != null) aEx.seekTo(syncUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                var vDone = false
                var aDone = af == null
                var clipEnd = offset
                while (!vDone || !aDone) {
                    if (cancelled) throw CancelledException()
                    val vT = if (vDone) Long.MAX_VALUE else vEx.sampleTime
                    val aT = if (aDone) Long.MAX_VALUE else aEx.sampleTime
                    if (!vDone && (vT < 0 || vT >= endUs)) {
                        vDone = true
                        continue
                    }
                    if (!aDone && (aT < 0 || aT >= endUs)) {
                        aDone = true
                        continue
                    }
                    if (vT <= aT) {
                        val n = vEx.readSampleData(buf, 0)
                        if (n < 0) {
                            vDone = true
                            continue
                        }
                        var outT = vT - syncUs + offset
                        if (outT <= lastVideoOut && (vEx.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
                            outT = lastVideoOut + 1
                        }
                        val flags = if ((vEx.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                        info.set(0, n, outT, flags)
                        m.writeSampleData(mv, buf, info)
                        lastVideoOut = maxOf(lastVideoOut, outT)
                        clipEnd = maxOf(clipEnd, outT + frameUs)
                        vEx.advance()
                        if (vT - lastReport > 300_000L || vT < lastReport) {
                            lastReport = vT
                            progress(((doneUs + (vT - syncUs)).toFloat() / totalUs).coerceIn(0f, 1f))
                        }
                    } else {
                        if (aT < syncUs) {
                            aEx.advance()
                            continue
                        }
                        val n = aEx.readSampleData(buf, 0)
                        if (n < 0) {
                            aDone = true
                            continue
                        }
                        var outT = aT - syncUs + offset
                        if (outT <= lastAudioOut) outT = lastAudioOut + 1
                        info.set(0, n, outT, 0)
                        m.writeSampleData(ma, buf, info)
                        lastAudioOut = outT
                        clipEnd = maxOf(clipEnd, outT + audioFrameUs)
                        aEx.advance()
                    }
                }
                offset = clipEnd
                doneUs += endUs - startUs
            }
            m.stop()
            started = false
            progress(1f)
        } finally {
            try {
                if (started) muxer?.stop()
            } catch (_: Exception) {
            }
            try {
                muxer?.release()
            } catch (_: Exception) {
            }
            vEx.release()
            aEx.release()
        }
    }
}

/** Re-encodes the chosen clips with Media3 Transformer: exact cut points, optional smaller size. Main thread. */
@OptIn(UnstableApi::class)
class ExactExporter(private val context: Context) {

    private var transformer: Transformer? = null
    private val progressHolder = ProgressHolder()

    fun start(
        uri: Uri,
        clipsMs: List<LongArray>,
        outputHeight: Int?,
        bitrate: Int,
        outFile: File,
        onDone: (Exception?) -> Unit
    ) {
        val videoEffects = ArrayList<Effect>()
        if (outputHeight != null) videoEffects.add(Presentation.createForHeight(outputHeight))
        val effects = Effects(ArrayList<AudioProcessor>(), videoEffects)

        val items = ArrayList<EditedMediaItem>()
        for (c in clipsMs) {
            val mediaItem = MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c[0])
                        .setEndPositionMs(c[1])
                        .build()
                )
                .build()
            items.add(EditedMediaItem.Builder(mediaItem).setEffects(effects).build())
        }

        val composition = Composition.Builder(listOf(EditedMediaItemSequence(items)))
            .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL)
            .build()

        val encoderFactory = DefaultEncoderFactory.Builder(context)
            .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
            .build()

        val t = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    transformer = null
                    onDone(null)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    transformer = null
                    onDone(exportException)
                }
            })
            .build()
        transformer = t
        if (outFile.exists()) outFile.delete()
        t.start(composition, outFile.absolutePath)
    }

    /** 0..100 */
    fun progress(): Int {
        val t = transformer ?: return 0
        val state = t.getProgress(progressHolder)
        return if (state == Transformer.PROGRESS_STATE_AVAILABLE) progressHolder.progress else 0
    }

    fun cancel() {
        try {
            transformer?.cancel()
        } catch (_: Exception) {
        }
        transformer = null
    }
}

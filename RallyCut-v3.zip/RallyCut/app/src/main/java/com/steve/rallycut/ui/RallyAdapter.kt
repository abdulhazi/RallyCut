package com.steve.rallycut.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.checkbox.MaterialCheckBox
import com.steve.rallycut.Fmt
import com.steve.rallycut.R
import com.steve.rallycut.RallyItem
import java.util.concurrent.Executors

class RallyAdapter(
    private val items: List<RallyItem>,
    private val thumbs: ThumbLoader,
    private val onClick: (RallyItem) -> Unit,
    private val onKeepChanged: (RallyItem) -> Unit
) : RecyclerView.Adapter<RallyAdapter.Holder>() {

    var selected: RallyItem? = null

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val root: View = v.findViewById(R.id.root)
        val bar: View = v.findViewById(R.id.bar)
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val title: TextView = v.findViewById(R.id.title)
        val times: TextView = v.findViewById(R.id.times)
        val detail: TextView = v.findViewById(R.id.detail)
        val keep: MaterialCheckBox = v.findViewById(R.id.keep)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_rally, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: Holder, position: Int) {
        val r = items[position]
        h.title.text = "Rally ${position + 1}" + if (r.manual) " (added by you)" else ""
        h.times.text = Fmt.clockTenths(r.startMs) + " – " + Fmt.clockTenths(r.endMs) + "  ·  " + Fmt.seconds(r.lengthMs)
        h.detail.text = if (r.manual) "" else {
            val conf = (r.confidence * 100).toInt().coerceIn(0, 100)
            (if (r.hits > 0) "${r.hits} hits · " else "found by movement · ") + "confidence $conf%"
        }
        h.bar.setBackgroundColor(if (r.keep) Color.rgb(67, 160, 71) else Color.rgb(158, 158, 158))
        h.root.alpha = if (r.keep) 1f else 0.55f
        h.root.setBackgroundColor(if (r === selected) Color.argb(60, 255, 193, 7) else Color.TRANSPARENT)
        h.keep.setOnCheckedChangeListener(null)
        h.keep.isChecked = r.keep
        h.keep.setOnCheckedChangeListener { _, checked ->
            r.keep = checked
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) notifyItemChanged(p)
            onKeepChanged(r)
        }
        h.root.setOnClickListener { onClick(r) }
        // a frame from early in the rally, where the action is
        thumbs.load(h.thumb, r.startMs + minOf(3000L, r.lengthMs / 3))
    }
}

/** Loads small frames off the main thread and caches them. */
class ThumbLoader(private val context: Context, private val uri: Uri) {
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val cache = object : LruCache<Long, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount
    }
    private var mmr: MediaMetadataRetriever? = null
    @Volatile private var closed = false

    fun load(view: ImageView, ms: Long) {
        val key = ms / 500 // half-second buckets
        view.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            view.setImageBitmap(hit)
            return
        }
        view.setImageDrawable(null)
        exec.execute {
            if (closed) return@execute
            if (view.tag != key) return@execute // view was reused for another rally
            val bmp = try {
                val r = mmr ?: MediaMetadataRetriever().also {
                    it.setDataSource(context, uri)
                    mmr = it
                }
                r.getScaledFrameAtTime(ms * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 256, 256)
            } catch (_: Exception) {
                null
            }
            if (bmp != null) {
                cache.put(key, bmp)
                main.post { if (view.tag == key) view.setImageBitmap(bmp) }
            }
        }
    }

    fun close() {
        closed = true
        exec.execute {
            try {
                mmr?.release()
            } catch (_: Exception) {
            }
            mmr = null
        }
        exec.shutdown()
    }
}

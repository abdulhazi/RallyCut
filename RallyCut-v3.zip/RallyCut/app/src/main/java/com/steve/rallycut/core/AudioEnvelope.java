package com.steve.rallycut.core;

/**
 * Streaming loudness of the high band (above 2 kHz, where the "thwack" of a shuttle hit lives),
 * one dB value per 10 ms. Feed mono samples in -1..1.
 */
public final class AudioEnvelope {
    public static final double HOP = 0.01;

    private final int hop;
    private final double b0, b1, b2, a1, a2;
    private double z1, z2;
    private double sum;
    private int count;
    private float[] env = new float[1 << 16];
    private int size;

    public AudioEnvelope(int sampleRate) {
        hop = (int) Math.round(sampleRate * HOP);
        double w0 = 2 * Math.PI * 2000.0 / sampleRate, q = 0.7071;
        double al = Math.sin(w0) / (2 * q), cs = Math.cos(w0);
        double a0 = 1 + al;
        b0 = (1 + cs) / 2 / a0;
        b1 = -(1 + cs) / a0;
        b2 = (1 + cs) / 2 / a0;
        a1 = -2 * cs / a0;
        a2 = (1 - al) / a0;
    }

    public void push(double x) {
        // transposed direct form II (same output as scipy.signal.lfilter)
        double y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        sum += y * y;
        if (++count == hop) {
            if (size == env.length) env = java.util.Arrays.copyOf(env, size * 2);
            env[size++] = (float) (10 * Math.log10(sum / hop + 1e-12));
            sum = 0;
            count = 0;
        }
    }

    public float[] result() {
        return java.util.Arrays.copyOf(env, size);
    }
}

package com.steve.rallycut

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator

class AnalyzeActivity : AppCompatActivity() {

    private lateinit var key: String
    private lateinit var progress: LinearProgressIndicator
    private lateinit var percent: TextView
    private lateinit var stage: TextView
    private lateinit var titleView: TextView
    private lateinit var cancel: MaterialButton
    private val main = Handler(Looper.getMainLooper())
    private var failed = false

    private val tick = object : Runnable {
        override fun run() {
            update()
            if (!isFinishing) main.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_analyze)
        val k = intent.getStringExtra(MainActivity.EXTRA_KEY)
        if (k == null) {
            finish()
            return
        }
        key = k
        progress = findViewById(R.id.progress)
        percent = findViewById(R.id.percent)
        stage = findViewById(R.id.stage)
        titleView = findViewById(R.id.title)
        cancel = findViewById(R.id.cancel)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cancel.setOnClickListener {
            if (failed) {
                backToCourt()
            } else {
                AnalysisJob.cancel()
                backToCourt()
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!failed) AnalysisJob.cancel()
                backToCourt()
            }
        })
    }

    override fun onResume() {
        super.onResume()
        main.post(tick)
    }

    override fun onPause() {
        super.onPause()
        main.removeCallbacks(tick)
    }

    private fun backToCourt() {
        startActivity(Intent(this, CourtActivity::class.java).putExtra(MainActivity.EXTRA_KEY, key))
        finish()
    }

    private fun update() {
        if (AnalysisJob.key != key) {
            // Nothing running for this video (e.g. the app was restarted): go back to marking.
            if (!AnalysisJob.running) backToCourt()
            return
        }
        if (AnalysisJob.finished) {
            main.removeCallbacks(tick)
            startActivity(Intent(this, ReviewActivity::class.java).putExtra(MainActivity.EXTRA_KEY, key))
            finish()
            return
        }
        val err = AnalysisJob.error
        if (err != null && !AnalysisJob.running) {
            failed = true
            titleView.text = "Couldn't analyse this video"
            stage.text = err
            cancel.text = "Back"
            return
        }
        val p = AnalysisJob.progress
        progress.progress = (p * 1000).toInt()
        val pct = (p * 100).toInt()
        val elapsed = (System.currentTimeMillis() - AnalysisJob.startedAt) / 1000.0
        val eta = if (p > 0.03f) ((elapsed / p) * (1 - p)).toLong() else -1L
        percent.text = if (eta >= 0) "$pct%  ·  about ${Fmt.eta(eta)} left" else "$pct%"
        stage.text = when {
            AnalysisJob.audioProgress < 1f -> "Listening for shuttle hits and watching your court…"
            else -> "Watching players and the shuttle in your court…"
        }
    }
}

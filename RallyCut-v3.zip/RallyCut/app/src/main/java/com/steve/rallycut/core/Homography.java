package com.steve.rallycut.core;

/**
 * Perspective mapping between court coordinates (u, v in 0..1) and image pixels.
 * u runs along the baselines, v runs from the far baseline (0) to the near baseline (1); the net is v = 0.5.
 */
public final class Homography {
    public final double[] m; // row-major 3x3

    private Homography(double[] m) {
        this.m = m;
    }

    /** Corners in order far-left, far-right, near-right, near-left as x0,y0,...,x3,y3. */
    public static Homography squareToQuad(float[] q) {
        double x0 = q[0], y0 = q[1], x1 = q[2], y1 = q[3], x2 = q[4], y2 = q[5], x3 = q[6], y3 = q[7];
        double dx1 = x1 - x2, dx2 = x3 - x2, dx3 = x0 - x1 + x2 - x3;
        double dy1 = y1 - y2, dy2 = y3 - y2, dy3 = y0 - y1 + y2 - y3;
        double g, h;
        if (Math.abs(dx3) < 1e-9 && Math.abs(dy3) < 1e-9) {
            g = 0;
            h = 0;
        } else {
            double den = dx1 * dy2 - dx2 * dy1;
            if (Math.abs(den) < 1e-12) den = 1e-12;
            g = (dx3 * dy2 - dx2 * dy3) / den;
            h = (dx1 * dy3 - dx3 * dy1) / den;
        }
        double a = x1 - x0 + g * x1, b = x3 - x0 + h * x3, c = x0;
        double d = y1 - y0 + g * y1, e = y3 - y0 + h * y3, f = y0;
        return new Homography(new double[]{a, b, c, d, e, f, g, h, 1.0});
    }

    public double mapX(double x, double y) {
        double w = m[6] * x + m[7] * y + m[8];
        return (m[0] * x + m[1] * y + m[2]) / w;
    }

    public double mapY(double x, double y) {
        double w = m[6] * x + m[7] * y + m[8];
        return (m[3] * x + m[4] * y + m[5]) / w;
    }

    public Homography inverse() {
        double a = m[0], b = m[1], c = m[2], d = m[3], e = m[4], f = m[5], g = m[6], h = m[7], i = m[8];
        double A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g;
        double det = a * A + b * B + c * C;
        if (Math.abs(det) < 1e-15) det = 1e-15;
        double[] r = new double[]{
                A / det, -(b * i - c * h) / det, (b * f - c * e) / det,
                B / det, (a * i - c * g) / det, -(a * f - c * d) / det,
                C / det, -(a * h - b * g) / det, (a * e - b * d) / det};
        return new Homography(r);
    }

    /**
     * Puts 4 freely placed points into court order (far-left, far-right, near-right, near-left).
     * The baseline nearest the camera is the edge lowest in the picture; flipNet makes the other
     * pair of edges the baselines (for cameras at the side of the court).
     * Returns null if the shape is not a convex quadrilateral.
     */
    public static float[] orderCorners(float[] pts, boolean flipNet) {
        double cx = 0, cy = 0;
        for (int i = 0; i < 4; i++) {
            cx += pts[2 * i];
            cy += pts[2 * i + 1];
        }
        cx /= 4;
        cy /= 4;
        Integer[] idx = {0, 1, 2, 3};
        final double fcx = cx, fcy = cy;
        java.util.Arrays.sort(idx, (p, q) -> Double.compare(
                Math.atan2(pts[2 * p + 1] - fcy, pts[2 * p] - fcx),
                Math.atan2(pts[2 * q + 1] - fcy, pts[2 * q] - fcx)));
        float[] s = new float[8];
        for (int i = 0; i < 4; i++) {
            s[2 * i] = pts[2 * idx[i]];
            s[2 * i + 1] = pts[2 * idx[i] + 1];
        }
        // convexity: all cross products have the same sign
        int sign = 0;
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4, k = (i + 2) % 4;
            double ux = s[2 * j] - s[2 * i], uy = s[2 * j + 1] - s[2 * i + 1];
            double vx = s[2 * k] - s[2 * j], vy = s[2 * k + 1] - s[2 * j + 1];
            double cr = ux * vy - uy * vx;
            int sg = cr > 1e-9 ? 1 : (cr < -1e-9 ? -1 : 0);
            if (sg == 0) return null;
            if (sign == 0) sign = sg;
            else if (sg != sign) return null;
        }
        // edge i goes from s[i] to s[i+1]; screen order is clockwise
        int best = 0;
        double bestY = -1e18;
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            double my = (s[2 * i + 1] + s[2 * j + 1]) / 2;
            if (my > bestY) {
                bestY = my;
                best = i;
            }
        }
        int start = best;
        if (flipNet) {
            int a = (best + 1) % 4, b = (best + 3) % 4;
            double ya = (s[2 * a + 1] + s[2 * ((a + 1) % 4) + 1]) / 2;
            double yb = (s[2 * b + 1] + s[2 * ((b + 1) % 4) + 1]) / 2;
            start = ya >= yb ? a : b;
        }
        // s[start] = near-right, s[start+1] = near-left, s[start+2] = far-left, s[start+3] = far-right
        float[] out = new float[8];
        int[] order = {(start + 2) % 4, (start + 3) % 4, start, (start + 1) % 4};
        for (int i = 0; i < 4; i++) {
            out[2 * i] = s[2 * order[i]];
            out[2 * i + 1] = s[2 * order[i] + 1];
        }
        return out;
    }
}

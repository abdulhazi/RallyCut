package com.steve.rallycut

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.steve.rallycut.core.AudioEnvelope
import com.steve.rallycut.core.CourtZone
import com.steve.rallycut.core.HitFinder
import com.steve.rallycut.core.Homography
import java.nio.ByteOrder

class CancelledException : RuntimeException("Cancelled")

private const val TIMEOUT_US = 10_000L

private fun findTrack(ex: MediaExtractor, prefix: String): Int {
    for (i in 0 until ex.trackCount) {
        val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
        if (mime.startsWith(prefix)) return i
    }
    return -1
}

/** Decodes the soundtrack and finds shuttle-hit candidates. Returns null when the video has no audio. */
object AudioPass {
    class Result(val candidates: List<FloatArray>, val durationSec: Double)

    fun run(context: Context, uri: Uri, progress: (Float) -> Unit, cancelled: () -> Boolean): Result? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(context, uri, null)
            val track = findTrack(ex, "audio/")
            if (track < 0) return null
            ex.selectTrack(track)
            val fmt = ex.getTrackFormat(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return null
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            var sampleRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
            var pcmFloat = false
            var env = AudioEnvelope(sampleRate)
            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var frames = 0L
            var lastReport = 0L
            while (!outputDone) {
                if (cancelled()) throw CancelledException()
                if (!inputDone) {
                    val ii = c.dequeueInputBuffer(TIMEOUT_US)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)
                        val n = if (buf != null) ex.readSampleData(buf, 0) else -1
                        if (n < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, TIMEOUT_US)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = c.outputFormat
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                    }
                    pcmFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        val sr = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (sr != sampleRate && frames == 0L) {
                            sampleRate = sr
                            env = AudioEnvelope(sr)
                        }
                    }
                } else if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = c.getOutputBuffer(oi)
                        if (ob != null) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            ob.order(ByteOrder.nativeOrder())
                            if (pcmFloat) {
                                val fb = ob.asFloatBuffer()
                                val count = fb.remaining() / channels
                                for (f in 0 until count) {
                                    var s = 0.0
                                    for (ch in 0 until channels) s += fb.get()
                                    env.push(s / channels)
                                }
                                frames += count
                            } else {
                                val sb = ob.asShortBuffer()
                                val count = sb.remaining() / channels
                                for (f in 0 until count) {
                                    var s = 0.0
                                    for (ch in 0 until channels) s += sb.get() / 32768.0
                                    env.push(s / channels)
                                }
                                frames += count
                            }
                        }
                    }
                    c.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    if (durUs > 0 && info.presentationTimeUs - lastReport > 500_000L) {
                        lastReport = info.presentationTimeUs
                        progress((info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f))
                    }
                }
            }
            progress(1f)
            return Result(HitFinder.candidates(env.result()), frames.toDouble() / sampleRate)
        } finally {
            try {
                codec?.stop()
            } catch (_: Exception) {
            }
            try {
                codec?.release()
            } catch (_: Exception) {
            }
            ex.release()
        }
    }
}

/**
 * Decodes the video (luma only, ~15 frames a second) and measures player motion and shuttle flight
 * inside the marked court. Returns null if this phone's decoder can't hand us readable frames.
 */
object VideoPass {
    const val ANALYSIS_FPS = 15.0

    class Result(val t: FloatArray, val near: FloatArray, val far: FloatArray, val blobs: FloatArray)

    private class Growable {
        var a = FloatArray(4096)
        var n = 0
        fun add(v: Float) {
            if (n == a.size) a = a.copyOf(n * 2)
            a[n++] = v
        }

        fun result(): FloatArray = a.copyOf(n)
    }

    /**
     * handlesNorm: the four corners, normalised in the upright frame (any order).
     * rotation: degrees the stored frames must be turned clockwise to stand upright.
     */
    fun run(
        context: Context, uri: Uri, handlesNorm: FloatArray, flipNet: Boolean, rotation: Int,
        progress: (Float) -> Unit, cancelled: () -> Boolean
    ): Result? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(context, uri, null)
            val track = findTrack(ex, "video/")
            if (track < 0) return null
            ex.selectTrack(track)
            val trackFmt = ex.getTrackFormat(track)
            val mime = trackFmt.getString(MediaFormat.KEY_MIME) ?: return null
            val durUs = if (trackFmt.containsKey(MediaFormat.KEY_DURATION)) trackFmt.getLong(MediaFormat.KEY_DURATION) else 0L
            val rawW = trackFmt.getInteger(MediaFormat.KEY_WIDTH)
            val rawH = trackFmt.getInteger(MediaFormat.KEY_HEIGHT)
            val dispW = if (rotation % 180 != 0) rawH else rawW
            val dispH = if (rotation % 180 != 0) rawW else rawH

            val ordered = Homography.orderCorners(handlesNorm, flipNet) ?: return null
            val px = FloatArray(8)
            for (i in 0 until 4) {
                px[2 * i] = ordered[2 * i] * dispW
                px[2 * i + 1] = ordered[2 * i + 1] * dispH
            }
            val zone = CourtZone(px, dispW, dispH, 320)

            var dec = createDecoder(mime, trackFmt)
            if (dec == null && mime == MediaFormat.MIMETYPE_VIDEO_DOLBY_VISION) {
                // Dolby Vision clips carry an HEVC base layer that the normal HEVC decoder can read
                val f2 = ex.getTrackFormat(track)
                f2.setString(MediaFormat.KEY_MIME, MediaFormat.MIMETYPE_VIDEO_HEVC)
                dec = createDecoder(MediaFormat.MIMETYPE_VIDEO_HEVC, f2)
            }
            if (dec == null) return null
            codec = dec
            dec.start()

            val n = zone.gw * zone.gh
            val lut = IntArray(n * 4)
            var lutStride = -1
            var lutPixel = -1
            var lutCropL = -1
            var lutCropT = -1
            var lutW = -1
            var lutH = -1
            var g0 = FloatArray(n)
            var g1 = FloatArray(n)
            var g2 = FloatArray(n)
            var have = 0
            var t1 = 0.0
            val feat = FloatArray(3)
            val outT = Growable()
            val outN = Growable()
            val outF = Growable()
            val outB = Growable()
            val stepUs = (1_000_000.0 / ANALYSIS_FPS).toLong()
            var nextUs = Long.MIN_VALUE
            var unreadable = 0
            var read = 0

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var lastReport = 0L
            while (!outputDone) {
                if (cancelled()) throw CancelledException()
                if (!inputDone) {
                    val ii = dec.dequeueInputBuffer(TIMEOUT_US)
                    if (ii >= 0) {
                        val buf = dec.getInputBuffer(ii)
                        val sz = if (buf != null) ex.readSampleData(buf, 0) else -1
                        if (sz < 0) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = dec.dequeueOutputBuffer(info, TIMEOUT_US)
                if (oi >= 0) {
                    val pts = info.presentationTimeUs
                    if (info.size > 0 && (nextUs == Long.MIN_VALUE || pts >= nextUs)) {
                        if (nextUs == Long.MIN_VALUE) nextUs = pts
                        while (nextUs <= pts) nextUs += stepUs
                        val image = try {
                            dec.getOutputImage(oi)
                        } catch (_: Exception) {
                            null
                        }
                        if (image == null) {
                            unreadable++
                        } else {
                            try {
                                val plane = image.planes[0]
                                val crop = image.cropRect
                                val cw = if (crop.width() > 0) crop.width() else image.width
                                val chh = if (crop.height() > 0) crop.height() else image.height
                                if (plane.rowStride != lutStride || plane.pixelStride != lutPixel ||
                                    crop.left != lutCropL || crop.top != lutCropT || cw != lutW || chh != lutH
                                ) {
                                    lutStride = plane.rowStride
                                    lutPixel = plane.pixelStride
                                    lutCropL = crop.left
                                    lutCropT = crop.top
                                    lutW = cw
                                    lutH = chh
                                    buildLut(zone, lut, dispW, dispH, rotation, cw, chh, crop.left, crop.top, lutStride, lutPixel)
                                }
                                val buf = plane.buffer
                                val limit = buf.limit()
                                for (k in 0 until n) {
                                    var s = 0
                                    for (j in 0 until 4) {
                                        val off = lut[4 * k + j]
                                        if (off < limit) s += buf.get(off).toInt() and 0xFF
                                    }
                                    g2[k] = s / 4f
                                }
                                read++
                            } finally {
                                image.close()
                            }
                            // rotate the three-frame window: g0 = two back, g1 = previous, g2 = current
                            have++
                            if (have >= 3) {
                                zone.features(g0, g1, g2, feat)
                                outT.add(t1.toFloat())
                                outN.add(feat[0])
                                outF.add(feat[1])
                                outB.add(feat[2])
                            }
                            val tmp = g0
                            g0 = g1
                            g1 = g2
                            g2 = tmp
                            t1 = pts / 1_000_000.0
                        }
                        if (unreadable > 30 && read == 0) return null
                    }
                    dec.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    if (durUs > 0 && pts - lastReport > 500_000L) {
                        lastReport = pts
                        progress((pts.toFloat() / durUs).coerceIn(0f, 1f))
                    }
                }
            }
            progress(1f)
            if (outT.n == 0) return null
            return Result(outT.result(), outN.result(), outF.result(), outB.result())
        } finally {
            try {
                codec?.stop()
            } catch (_: Exception) {
            }
            try {
                codec?.release()
            } catch (_: Exception) {
            }
            ex.release()
        }
    }

    private fun createDecoder(mime: String, fmt: MediaFormat): MediaCodec? {
        // First try with "decode as fast as possible" hints, then plain.
        for (attempt in 0 until 2) {
            var c: MediaCodec? = null
            try {
                c = MediaCodec.createDecoderByType(mime)
                fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                if (attempt == 0) {
                    fmt.setInteger(MediaFormat.KEY_PRIORITY, 1)
                    fmt.setInteger(MediaFormat.KEY_OPERATING_RATE, Short.MAX_VALUE.toInt())
                } else {
                    fmt.removeKey(MediaFormat.KEY_PRIORITY)
                    fmt.removeKey(MediaFormat.KEY_OPERATING_RATE)
                }
                c.configure(fmt, null, null, 0)
                return c
            } catch (_: Exception) {
                try {
                    c?.release()
                } catch (_: Exception) {
                }
            }
        }
        return null
    }

    /** For each grid cell, the byte offsets of its 4 sample points in the stored (unrotated) luma plane. */
    private fun buildLut(
        zone: CourtZone, lut: IntArray, dispW: Int, dispH: Int, rotation: Int,
        rawW: Int, rawH: Int, cropL: Int, cropT: Int, rowStride: Int, pixelStride: Int
    ) {
        // 10-bit frames (HDR) store each luma sample in 2 bytes, little endian, value in the high bits.
        val highByte = if (pixelStride >= 2) 1 else 0
        for (r in 0 until zone.gh) {
            for (col in 0 until zone.gw) {
                val k = r * zone.gw + col
                for (j in 0 until 4) {
                    val dx = if (j % 2 == 0) zone.sx0[col] else zone.sx1[col]
                    val dy = if (j < 2) zone.sy0[r] else zone.sy1[r]
                    val nx = (dx + 0.5) / dispW
                    val ny = (dy + 0.5) / dispH
                    val rx: Double
                    val ry: Double
                    when (rotation) {
                        90 -> {
                            rx = ny; ry = 1 - nx
                        }
                        180 -> {
                            rx = 1 - nx; ry = 1 - ny
                        }
                        270 -> {
                            rx = 1 - ny; ry = nx
                        }
                        else -> {
                            rx = nx; ry = ny
                        }
                    }
                    val x = (rx * rawW).toInt().coerceIn(0, rawW - 1)
                    val y = (ry * rawH).toInt().coerceIn(0, rawH - 1)
                    lut[4 * k + j] = (cropT + y) * rowStride + (cropL + x) * pixelStride + highByte
                }
            }
        }
    }
}

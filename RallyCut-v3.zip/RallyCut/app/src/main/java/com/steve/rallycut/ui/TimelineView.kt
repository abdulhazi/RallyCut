package com.steve.rallycut.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.steve.rallycut.RallyItem

/** Whole-video bar: rallies (green = keep, grey = removed), the activity curve, and the playhead. Tap to seek. */
class TimelineView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    var durationMs = 1L
        set(v) {
            field = v.coerceAtLeast(1)
            invalidate()
        }
    var rallies: List<RallyItem> = emptyList()
        set(v) {
            field = v
            invalidate()
        }
    var selected: RallyItem? = null
        set(v) {
            field = v
            invalidate()
        }
    var playheadMs = 0L
        set(v) {
            if (v != field) {
                field = v
                invalidate()
            }
        }

    /** Activity 0..1 sampled evenly over the video (optional). */
    var activity: FloatArray? = null
        set(v) {
            field = v
            invalidate()
        }

    var onSeek: ((Long) -> Unit)? = null

    private val dp = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 128, 128, 128) }
    private val act = Paint().apply { color = Color.argb(90, 129, 199, 132) }
    private val keep = Paint().apply { color = Color.rgb(67, 160, 71) }
    private val removed = Paint().apply { color = Color.argb(150, 117, 117, 117) }
    private val sel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 193, 7)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * dp
    }
    private val head = Paint().apply {
        color = Color.rgb(244, 67, 54)
        strokeWidth = 2f * dp
    }
    private val r = RectF()

    private fun xOf(ms: Long): Float = (ms.toDouble() / durationMs * width).toFloat()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val h = height.toFloat()
        val top = 6 * dp
        val bottom = h - 6 * dp
        r.set(0f, top, width.toFloat(), bottom)
        canvas.drawRoundRect(r, 4 * dp, 4 * dp, track)
        activity?.let { a ->
            if (a.isNotEmpty()) {
                val step = width.toFloat() / a.size
                for (i in a.indices) {
                    val v = a[i]
                    if (v <= 0.02f) continue
                    val y = bottom - (bottom - top) * v
                    canvas.drawRect(i * step, y, (i + 1) * step + 0.5f, bottom, act)
                }
            }
        }
        for (ra in rallies) {
            val x0 = xOf(ra.startMs)
            val x1 = maxOf(xOf(ra.endMs), x0 + 2 * dp)
            canvas.drawRect(x0, top + 6 * dp, x1, bottom - 6 * dp, if (ra.keep) keep else removed)
        }
        selected?.let { s ->
            val x0 = xOf(s.startMs)
            val x1 = maxOf(xOf(s.endMs), x0 + 2 * dp)
            canvas.drawRect(x0, top + 2 * dp, x1, bottom - 2 * dp, sel)
        }
        val px = xOf(playheadMs)
        canvas.drawLine(px, 0f, px, h, head)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val ms = (e.x.coerceIn(0f, width.toFloat()) / width * durationMs).toLong()
                playheadMs = ms
                onSeek?.invoke(ms)
                return true
            }
            MotionEvent.ACTION_UP -> {
                performClick()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}

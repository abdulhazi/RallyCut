package com.steve.rallycut.core;

/**
 * Low-resolution analysis grid (display coordinates) covering the marked court plus the air above it.
 * Each cell is the average of 2x2 sample points. Also computes per-frame features:
 * player motion in the near/far halves and isolated small moving blobs (the shuttle).
 */
public final class CourtZone {
    public final int gw, gh;
    public final double x0, y0, cell;
    public final boolean[] near, far, shuttleZone;
    public final int nn, nf;
    /** Sample positions in display pixels: column samples sx0/sx1 (per grid column), rows sy0/sy1. */
    public final int[] sx0, sx1, sy0, sy1;

    // scratch
    private final float[] d1, d2;
    private final boolean[] sm, any;
    private final int[] label, queue, hist;

    /** corners: ordered display-pixel quad (far-left, far-right, near-right, near-left). */
    public CourtZone(float[] corners, int dispW, int dispH, int maxCells) {
        Homography hm = Homography.squareToQuad(corners);
        Homography inv = hm.inverse();
        double minX = 1e18, maxX = -1e18, minY = 1e18, maxY = -1e18;
        for (int i = 0; i < 4; i++) {
            minX = Math.min(minX, corners[2 * i]);
            maxX = Math.max(maxX, corners[2 * i]);
            minY = Math.min(minY, corners[2 * i + 1]);
            maxY = Math.max(maxY, corners[2 * i + 1]);
        }
        double ch = maxY - minY, cw = maxX - minX;
        double bx0 = Math.max(0, minX - 0.08 * cw), bx1 = Math.min(dispW, maxX + 0.08 * cw);
        double by0 = Math.max(0, minY - 0.9 * ch), by1 = Math.min(dispH, maxY + 0.05 * ch);
        double c = Math.max(Math.max((bx1 - bx0) / maxCells, (by1 - by0) / maxCells), 1.0);
        gw = Math.max(8, (int) ((bx1 - bx0) / c));
        gh = Math.max(8, (int) ((by1 - by0) / c));
        x0 = bx0;
        y0 = by0;
        cell = c;
        int n = gw * gh;
        boolean[] incourt = new boolean[n];
        near = new boolean[n];
        boolean[] farTmp = new boolean[n];
        for (int r = 0; r < gh; r++) {
            double py = y0 + (r + 0.5) * c;
            for (int col = 0; col < gw; col++) {
                double px = x0 + (col + 0.5) * c;
                double u = inv.mapX(px, py), v = inv.mapY(px, py);
                boolean in = u >= -0.12 && u <= 1.12 && v >= -0.12 && v <= 1.12;
                int k = r * gw + col;
                incourt[k] = in;
                if (in) {
                    if (v >= 0.5) near[k] = true;
                    else farTmp[k] = true;
                }
            }
        }
        double lift = 0.9 * ch, body = 0.4 * ch;
        boolean[] air = new boolean[n];
        for (int col = 0; col < gw; col++) {
            int top = -1;
            for (int r = 0; r < gh; r++) {
                if (incourt[r * gw + col]) {
                    top = r;
                    break;
                }
            }
            if (top < 0) continue;
            for (int r = top - 1; r >= 0; r--) {
                double dy = (top - r) * c;
                if (dy <= lift) air[r * gw + col] = true;
                if (dy <= body) farTmp[r * gw + col] = true;
            }
        }
        far = farTmp;
        shuttleZone = new boolean[n];
        int cn = 0, cf = 0;
        for (int k = 0; k < n; k++) {
            shuttleZone[k] = incourt[k] || air[k];
            if (near[k]) cn++;
            if (far[k]) cf++;
        }
        nn = Math.max(1, cn);
        nf = Math.max(1, cf);
        sx0 = new int[gw];
        sx1 = new int[gw];
        sy0 = new int[gh];
        sy1 = new int[gh];
        for (int col = 0; col < gw; col++) {
            sx0[col] = clamp((int) (x0 + (col + 0.25) * c), 0, dispW - 1);
            sx1[col] = clamp((int) (x0 + (col + 0.75) * c), 0, dispW - 1);
        }
        for (int r = 0; r < gh; r++) {
            sy0[r] = clamp((int) (y0 + (r + 0.25) * c), 0, dispH - 1);
            sy1[r] = clamp((int) (y0 + (r + 0.75) * c), 0, dispH - 1);
        }
        d1 = new float[n];
        d2 = new float[n];
        sm = new boolean[n];
        any = new boolean[n];
        label = new int[n];
        queue = new int[n];
        hist = new int[1024 + 1];
    }

    private static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    /**
     * Features of the middle frame. Grids are cell averages (0..255).
     * out[0] = near-half motion fraction, out[1] = far-half motion fraction, out[2] = isolated small blobs (0..3).
     */
    public void features(float[] gPrev2, float[] gPrev, float[] gCur, float[] out) {
        int n = gw * gh;
        int zoneCount = 0;
        java.util.Arrays.fill(hist, 0);
        for (int k = 0; k < n; k++) {
            float a = Math.abs(gPrev[k] - gPrev2[k]);
            float b = Math.abs(gCur[k] - gPrev[k]);
            d1[k] = a;
            d2[k] = b;
            if (shuttleZone[k]) {
                int bin = Math.round(a * 4f);
                if (bin > 1024) bin = 1024;
                hist[bin]++;
                zoneCount++;
            }
        }
        double noise = medianFromHist(zoneCount);
        double thrM = Math.max(12.0, 4 * noise + 6);
        double thrS = Math.max(10.0, 3 * noise + 6);
        int mn = 0, mf = 0;
        for (int k = 0; k < n; k++) {
            float a = d1[k], b = d2[k];
            if (a > thrM) {
                if (near[k]) mn++;
                if (far[k]) mf++;
            }
            float s = Math.min(a, b);
            sm[k] = s > thrS && shuttleZone[k];
            any[k] = Math.max(a, b) > thrS;
            label[k] = 0;
        }
        out[0] = mn / (float) nn;
        out[1] = mf / (float) nf;
        // 4-connected components of the shuttle mask
        int count = 0, next = 0;
        for (int k = 0; k < n; k++) {
            if (!sm[k] || label[k] != 0) continue;
            next++;
            int head = 0, tail = 0;
            queue[tail++] = k;
            label[k] = next;
            int minR = Integer.MAX_VALUE, maxR = -1, minC = Integer.MAX_VALUE, maxC = -1;
            while (head < tail) {
                int p = queue[head++];
                int r = p / gw, c = p % gw;
                if (r < minR) minR = r;
                if (r > maxR) maxR = r;
                if (c < minC) minC = c;
                if (c > maxC) maxC = c;
                if (c > 0) tail = push(p - 1, next, queue, tail);
                if (c < gw - 1) tail = push(p + 1, next, queue, tail);
                if (r > 0) tail = push(p - gw, next, queue, tail);
                if (r < gh - 1) tail = push(p + gw, next, queue, tail);
            }
            int size = tail;
            if (size > 12) continue;
            int r0 = Math.max(0, minR - 3), r1 = Math.min(gh, maxR + 4);
            int c0 = Math.max(0, minC - 3), c1 = Math.min(gw, maxC + 4);
            int moving = 0, own = 0;
            for (int r = r0; r < r1; r++) {
                for (int c = c0; c < c1; c++) {
                    int q = r * gw + c;
                    if (any[q]) moving++;
                    if (label[q] == next) own++;
                }
            }
            if (moving - own <= 1) count++;
        }
        out[2] = Math.min(count, 3);
    }

    private int push(int q, int lab, int[] queue, int tail) {
        if (sm[q] && label[q] == 0) {
            label[q] = lab;
            queue[tail++] = q;
        }
        return tail;
    }

    /** Median of the histogrammed values (quarter steps), averaging the two middle values like numpy. */
    private double medianFromHist(int total) {
        if (total == 0) return 0;
        int k1 = (total - 1) / 2, k2 = total / 2;
        double v1 = -1, v2 = -1;
        int acc = 0;
        for (int b = 0; b < hist.length; b++) {
            acc += hist[b];
            if (v1 < 0 && acc > k1) v1 = b / 4.0;
            if (acc > k2) {
                v2 = b / 4.0;
                break;
            }
        }
        if (v2 < 0) v2 = v1;
        return (v1 + v2) / 2;
    }
}

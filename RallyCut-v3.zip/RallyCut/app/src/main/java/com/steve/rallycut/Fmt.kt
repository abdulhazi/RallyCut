package com.steve.rallycut

import java.util.Locale

object Fmt {
    /** 1:02:03 or 2:03 */
    fun clock(ms: Long): String {
        val t = (ms.coerceAtLeast(0) / 1000)
        val h = t / 3600
        val m = (t % 3600) / 60
        val s = t % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    /** 2:03.4 */
    fun clockTenths(ms: Long): String {
        val v = ms.coerceAtLeast(0)
        val tenths = (v % 1000) / 100
        return clock(v) + "." + tenths
    }

    /** 17.4 s */
    fun seconds(ms: Long): String = String.format(Locale.US, "%.1f s", ms / 1000.0)

    fun eta(sec: Long): String = when {
        sec < 60 -> "${sec}s"
        sec < 3600 -> "${sec / 60} min"
        else -> String.format(Locale.US, "%d h %02d min", sec / 3600, (sec % 3600) / 60)
    }

    fun size(bytes: Long): String = when {
        bytes < 0 -> "?"
        bytes >= 1L shl 30 -> String.format(Locale.US, "%.2f GB", bytes / (1L shl 30).toDouble())
        bytes >= 1L shl 20 -> String.format(Locale.US, "%.0f MB", bytes / (1L shl 20).toDouble())
        else -> String.format(Locale.US, "%d KB", bytes / 1024)
    }
}

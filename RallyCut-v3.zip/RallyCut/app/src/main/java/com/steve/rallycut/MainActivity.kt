package com.steve.rallycut

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var resume: MaterialButton
    private lateinit var pick: MaterialButton
    private lateinit var loading: ProgressBar
    private val main = Handler(Looper.getMainLooper())

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onPicked(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        pick = findViewById(R.id.pick)
        resume = findViewById(R.id.resume)
        loading = findViewById(R.id.loading)
        pick.setOnClickListener { picker.launch(arrayOf("video/*")) }
    }

    override fun onResume() {
        super.onResume()
        val key = SessionStore.lastKey(this)
        val s = key?.let { SessionStore.load(this, it) }
        if (s == null) {
            resume.visibility = View.GONE
        } else {
            resume.visibility = View.VISIBLE
            val kept = s.rallies.count { it.keep }
            resume.text = if (s.analysed) "Continue: ${s.name} ($kept rallies kept)" else "Continue: ${s.name}"
            resume.setOnClickListener { openSession(s) }
        }
    }

    private fun onPicked(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
        }
        loading.visibility = View.VISIBLE
        pick.isEnabled = false
        thread {
            try {
                val info = VideoInfo.load(this, uri)
                if (info.rawWidth <= 0 || info.durationMs <= 0) throw IllegalStateException("This file doesn't look like a video")
                val key = Session.keyFor(uri, info.sizeBytes)
                val existing = SessionStore.load(this, key)
                val s = existing ?: Session(
                    key, uri, info.name, info.sizeBytes, info.durationMs, info.rawWidth, info.rawHeight, info.rotation
                ).also { SessionStore.save(this, it) }
                SessionStore.setLastKey(this, key)
                main.post {
                    loading.visibility = View.GONE
                    pick.isEnabled = true
                    openSession(s)
                }
            } catch (e: Exception) {
                main.post {
                    loading.visibility = View.GONE
                    pick.isEnabled = true
                    Toast.makeText(this, "Couldn't open the video: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun openSession(s: Session) {
        val target = if (s.analysed && SessionStore.hasFeatures(this, s.key)) ReviewActivity::class.java
        else CourtActivity::class.java
        startActivity(Intent(this, target).putExtra(EXTRA_KEY, s.key))
    }

    companion object {
        const val EXTRA_KEY = "key"
    }
}

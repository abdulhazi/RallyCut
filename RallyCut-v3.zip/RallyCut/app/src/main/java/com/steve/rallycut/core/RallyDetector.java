package com.steve.rallycut.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Fuses shuttle-hit sounds with player motion and shuttle flight inside the marked court into rallies.
 * Pure Java, no Android calls, so it is fast to re-run when the user moves the sensitivity slider.
 */
public final class RallyDetector {
    public static final double BIN = 0.1;

    private RallyDetector() {
    }

    public static final class Params {
        public double sensitivity = 0.5; // 0..1
        public double preRoll = 1.8;      // seconds kept before the first hit
        public double postRoll = 1.8;     // seconds kept after the last hit
        /** Loudness (dB) a hit needs to count as "our court"; NaN = automatic. */
        public double levelOverride = Double.NaN;
    }

    public static final class Rally {
        public double start, end, confidence;
        public int hits;

        Rally(double start, double end, int hits, double confidence) {
            this.start = start;
            this.end = end;
            this.hits = hits;
            this.confidence = confidence;
        }
    }

    /** Visual activity curves at 10 Hz: v = combined (0..1), m = player motion, s = shuttle presence. */
    public static final class Visual {
        public final double[] v, m, s;

        Visual(double[] v, double[] m, double[] s) {
            this.v = v;
            this.m = m;
            this.s = s;
        }
    }

    static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    static double pct(double[] x, int n, double p) {
        if (n == 0) return 0.0;
        double[] s = Arrays.copyOf(x, n);
        Arrays.sort(s);
        return s[(int) (p * (n - 1))];
    }

    static double[] smooth(double[] x, int half) {
        int n = x.length;
        double[] out = new double[n];
        double[] pre = new double[n + 1];
        for (int i = 0; i < n; i++) pre[i + 1] = pre[i] + x[i];
        for (int i = 0; i < n; i++) {
            int a = Math.max(0, i - half), b = Math.min(n, i + half + 1);
            out[i] = (pre[b] - pre[a]) / (b - a);
        }
        return out;
    }

    static double clip01(double v) {
        return v < 0 ? 0 : (v > 1 ? 1 : v);
    }

    /** frames: times (s), near/far motion fractions, blob counts. Returns null if there are no frames. */
    public static Visual visualCurve(float[] t, float[] nearF, float[] farF, float[] blobs, double duration) {
        int count = t.length;
        if (count == 0) return null;
        int nb = (int) Math.ceil(duration / BIN) + 1;
        double[] mn = new double[nb], mf = new double[nb], sh = new double[nb];
        int[] cnt = new int[nb];
        for (int i = 0; i < count; i++) {
            int b = Math.min(nb - 1, (int) (t[i] / BIN));
            if (b < 0) b = 0;
            mn[b] = Math.max(mn[b], nearF[i]);
            mf[b] = Math.max(mf[b], farF[i]);
            if (blobs[i] > 0) sh[b] += 1;
            cnt[b]++;
        }
        double[] hn = new double[nb], hf = new double[nb];
        int h = 0;
        for (int b = 0; b < nb; b++) {
            sh[b] = cnt[b] > 0 ? sh[b] / cnt[b] : 0;
            if (cnt[b] > 0) {
                hn[h] = mn[b];
                hf[h] = mf[b];
                h++;
            }
        }
        double pn = Math.max(pct(hn, h, 0.95), 0.01), pf = Math.max(pct(hf, h, 0.95), 0.01);
        double[] g = new double[nb];
        for (int b = 0; b < nb; b++) g[b] = Math.sqrt(clip01(mn[b] / pn) * clip01(mf[b] / pf));
        double[] m = smooth(g, 5);
        double[] s = smooth(sh, 7);
        double[] hs = new double[nb];
        h = 0;
        for (int b = 0; b < nb; b++) if (cnt[b] > 0) hs[h++] = s[b];
        double ps = Math.max(pct(hs, h, 0.95), 0.05);
        double[] v = new double[nb];
        for (int b = 0; b < nb; b++) {
            s[b] = clip01(s[b] / ps);
            v[b] = 0.6 * m[b] + 0.4 * s[b];
        }
        double[] hv = new double[nb];
        h = 0;
        for (int b = 0; b < nb; b++) if (cnt[b] > 0) hv[h++] = v[b];
        double lo = pct(hv, h, 0.25), hi = pct(hv, h, 0.90);
        double span = Math.max(hi - lo, 0.05);
        for (int b = 0; b < nb; b++) v[b] = clip01((v[b] - lo) / span);
        return new Visual(v, m, s);
    }

    static double meanRange(double[] v, double t0, double t1) {
        int a = Math.max(0, (int) (t0 / BIN));
        int b = Math.min(v.length, (int) Math.ceil(t1 / BIN) + 1);
        if (b <= a) return 0.0;
        double s = 0;
        for (int i = a; i < b; i++) s += v[i];
        return s / (b - a);
    }

    /** Otsu split of sorted values: threshold between the two classes. */
    static double otsu(double[] v) {
        int n = v.length;
        double[] pre = new double[n + 1];
        for (int i = 0; i < n; i++) pre[i + 1] = pre[i] + v[i];
        double best = -1, thr = v[0];
        for (int i = 1; i < n; i++) {
            double ma = pre[i] / i, mb = (pre[n] - pre[i]) / (n - i);
            double w = (double) i * (n - i) * (ma - mb) * (ma - mb);
            if (w > best) {
                best = w;
                thr = (v[i - 1] + v[i]) / 2;
            }
        }
        return thr;
    }

    /**
     * Our own court is closest to the phone, so its hits form the loudest cluster of sounds.
     * Split repeatedly while the louder part stays a clearly separate, sizeable cluster.
     */
    public static double loudestClusterThreshold(double[] levels) {
        int total = levels.length;
        double thr = -1e9;
        double[] vals = levels.clone();
        Arrays.sort(vals);
        while (vals.length >= 12) {
            double t = otsu(vals);
            int split = 0;
            while (split < vals.length && vals[split] <= t) split++;
            int nLo = split, nHi = vals.length - split;
            if (nLo == 0 || nHi == 0) break;
            double sLo = 0, sHi = 0;
            for (int i = 0; i < split; i++) sLo += vals[i];
            for (int i = split; i < vals.length; i++) sHi += vals[i];
            if (sHi / nHi - sLo / nLo < 6.0 || nHi < 0.15 * total || nHi < 8) break;
            thr = t;
            vals = Arrays.copyOfRange(vals, split, vals.length);
        }
        return thr;
    }

    /** The automatic loudness threshold for "our court" hits at this sensitivity (before any override). */
    public static double autoLevelThreshold(List<float[]> cands, double sensitivity) {
        double promThr = lerp(14.0, 7.0, sensitivity);
        int n = 0;
        for (float[] c : cands) if (c[1] >= promThr) n++;
        double[] lv = new double[n];
        int i = 0;
        for (float[] c : cands) if (c[1] >= promThr) lv[i++] = c[2];
        return loudestClusterThreshold(lv);
    }

    /** cands: {t, prominence, level}; vis may be null (video analysis unavailable). */
    public static List<Rally> detect(List<float[]> cands, Visual vis, double duration, Params p) {
        double sens = p.sensitivity;
        double promThr = lerp(14.0, 7.0, sens);
        double gate = lerp(0.35, 0.10, sens);
        int minHits = sens < 0.3 ? 4 : 3;
        double visOnlyThr = lerp(0.8, 0.6, sens);
        double maxGap = 2.5, bridgeGap = 4.5;
        double[] V, M;
        if (vis != null) {
            V = vis.v;
            M = vis.m;
        } else {
            V = new double[(int) (duration / BIN) + 2];
            Arrays.fill(V, 0.5);
            M = V;
        }
        double moveGate = lerp(0.30, 0.15, sens);
        int strongCount = 0;
        for (float[] c : cands) if (c[1] >= promThr) strongCount++;
        boolean audioOk = strongCount >= 2 * duration / 60.0;
        double levelThr = Double.isNaN(p.levelOverride) ? autoLevelThreshold(cands, sens) : p.levelOverride;
        levelThr -= (sens - 0.5) * 6;

        List<Double> strong = new ArrayList<>(), weak = new ArrayList<>();
        for (float[] c : cands) {
            double t = c[0], pr = c[1], l = c[2];
            double v = meanRange(V, t - 0.7, t + 0.7);
            if (pr >= promThr && l >= levelThr && v >= gate) strong.add(t);
            else if (pr >= promThr - 3 && v >= gate + 0.1) weak.add(t);
        }
        List<double[]> rallies = new ArrayList<>(); // {start, end, hits}
        if (audioOk) {
            List<List<Double>> chains = new ArrayList<>();
            for (double t : strong) {
                if (!chains.isEmpty()) {
                    List<Double> ch = chains.get(chains.size() - 1);
                    double last = ch.get(ch.size() - 1), gap = t - last;
                    if (gap <= maxGap || (gap <= bridgeGap && meanRange(V, last, t) >= 0.45)) {
                        ch.add(t);
                        continue;
                    }
                }
                List<Double> nc = new ArrayList<>();
                nc.add(t);
                chains.add(nc);
            }
            for (List<Double> ch : chains) {
                double a = ch.get(0), b = ch.get(ch.size() - 1);
                double mv = meanRange(V, a, b);
                boolean playersMoving = meanRange(M, a, b) >= moveGate || ch.size() >= 8;
                if (playersMoving && (ch.size() >= minHits || (ch.size() == 2 && mv >= 0.5))) {
                    rallies.add(new double[]{a, b, ch.size()});
                }
            }
            // soft serves / soft final shots: extend with nearby weak hits
            for (double[] r : rallies) {
                List<Double> before = new ArrayList<>(), after = new ArrayList<>();
                for (double t : weak) {
                    if (r[0] - maxGap <= t && t < r[0]) before.add(t);
                    else if (r[1] < t && t <= r[1] + maxGap) after.add(t);
                }
                if (!before.isEmpty()) {
                    r[0] = before.get(Math.max(0, before.size() - 2));
                    r[2] += Math.min(2, before.size());
                }
                if (!after.isEmpty()) {
                    r[1] = after.get(0);
                    r[2] += 1;
                }
            }
        }
        // visual-only rallies (hit sounds missed)
        if (vis != null) {
            double thr = audioOk ? visOnlyThr : lerp(0.65, 0.45, sens);
            int b = 0;
            int n = V.length;
            List<double[]> extra = new ArrayList<>();
            while (b < n) {
                if (V[b] >= thr) {
                    int e = b;
                    while (e + 1 < n && V[e + 1] >= thr) e++;
                    double t0 = b * BIN, t1 = (e + 1) * BIN;
                    boolean overlaps = false;
                    for (double[] r : rallies) {
                        if (r[0] - 3 < t1 && t0 < r[1] + 3) {
                            overlaps = true;
                            break;
                        }
                    }
                    for (double[] r : extra) {
                        if (r[0] - 3 < t1 && t0 < r[1] + 3) {
                            overlaps = true;
                            break;
                        }
                    }
                    if (t1 - t0 >= 4.0 && !overlaps) extra.add(new double[]{t0 + 0.5, t1 - 0.5, 0});
                    b = e + 1;
                } else {
                    b++;
                }
            }
            rallies.addAll(extra);
        }
        rallies.sort((x, y) -> {
            int c = Double.compare(x[0], y[0]);
            if (c != 0) return c;
            c = Double.compare(x[1], y[1]);
            return c != 0 ? c : Double.compare(x[2], y[2]);
        });
        List<double[]> merged = new ArrayList<>();
        for (double[] r : rallies) {
            double a = Math.max(0.0, r[0] - p.preRoll), b = Math.min(duration, r[1] + p.postRoll);
            if (!merged.isEmpty() && a <= merged.get(merged.size() - 1)[1]) {
                double[] last = merged.get(merged.size() - 1);
                last[1] = Math.max(last[1], b);
                last[2] += r[2];
            } else {
                merged.add(new double[]{a, b, r[2]});
            }
        }
        List<Rally> out = new ArrayList<>();
        for (double[] r : merged) {
            double conf = 0.5 * Math.min(1.0, r[2] / 6.0) + 0.5 * meanRange(V, r[0], r[1]);
            out.add(new Rally(r[0], r[1], (int) r[2], conf));
        }
        return out;
    }

    /**
     * "Tune to this rally": the loudness threshold that keeps most hits inside a rally the user confirmed.
     * Returns NaN if there are too few sounds in it.
     */
    public static double levelFromRally(List<float[]> cands, double start, double end, double sensitivity) {
        double promThr = lerp(14.0, 7.0, sensitivity) - 3;
        List<Double> lv = new ArrayList<>();
        for (float[] c : cands) if (c[0] >= start && c[0] <= end && c[1] >= promThr) lv.add((double) c[2]);
        if (lv.size() < 3) return Double.NaN;
        double[] a = new double[lv.size()];
        for (int i = 0; i < a.length; i++) a[i] = lv.get(i);
        Arrays.sort(a);
        // shoe squeaks and other quiet transients can be inside a rally too: keep only the loud cluster
        while (a.length >= 6) {
            double t = otsu(a);
            int split = 0;
            while (split < a.length && a[split] <= t) split++;
            int nHi = a.length - split;
            if (split == 0 || nHi < 3 || nHi < 0.3 * a.length) break;
            double sLo = 0, sHi = 0;
            for (int i = 0; i < split; i++) sLo += a[i];
            for (int i = split; i < a.length; i++) sHi += a[i];
            if (sHi / nHi - sLo / split < 6.0) break;
            a = Arrays.copyOfRange(a, split, a.length);
        }
        // threshold is applied as (override - (sens - 0.5) * 6); compensate so most of this rally's hits pass
        return a[(int) (0.2 * (a.length - 1))] - 1.0 + (sensitivity - 0.5) * 6;
    }
}

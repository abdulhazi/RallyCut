package com.steve.rallycut

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.steve.rallycut.ui.CourtMarkerView
import java.util.concurrent.Executors

class CourtActivity : AppCompatActivity() {

    private lateinit var session: Session
    private lateinit var marker: CourtMarkerView
    private lateinit var frameLabel: TextView
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var retriever: MediaMetadataRetriever? = null
    @Volatile private var wantedMs = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_court)
        val key = intent.getStringExtra(MainActivity.EXTRA_KEY)
        val s = key?.let { SessionStore.load(this, it) }
        if (s == null) {
            finish()
            return
        }
        session = s
        marker = findViewById(R.id.marker)
        frameLabel = findViewById(R.id.frameLabel)
        val start = s.handles ?: SessionStore.lastHandles(this)
        if (start != null) marker.setHandles(start)
        marker.flipNet = s.flipNet

        findViewById<MaterialButton>(R.id.flipNet).setOnClickListener { marker.flipNet = !marker.flipNet }
        findViewById<MaterialButton>(R.id.reset).setOnClickListener {
            marker.setHandles(floatArrayOf(0.30f, 0.35f, 0.70f, 0.35f, 0.88f, 0.88f, 0.12f, 0.88f))
            marker.flipNet = false
        }
        findViewById<MaterialButton>(R.id.analyze).setOnClickListener { startAnalysis() }

        val seek = findViewById<SeekBar>(R.id.frameSeek)
        seek.progress = 150
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                frameLabel.text = "Frame shown: " + Fmt.clock(session.durationMs * progress / 1000) +
                        " (slide to pick a clearer frame)"
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}

            override fun onStopTrackingTouch(sb: SeekBar) {
                loadFrame(session.durationMs * sb.progress / 1000)
            }
        })
        frameLabel.text = "Frame shown: " + Fmt.clock(session.durationMs * 150 / 1000) + " (slide to pick a clearer frame)"
        loadFrame(session.durationMs * 150 / 1000)
    }

    private fun loadFrame(ms: Long) {
        wantedMs = ms
        worker.execute {
            if (wantedMs != ms) return@execute // a newer request is waiting
            try {
                val r = retriever ?: MediaMetadataRetriever().also {
                    it.setDataSource(this, session.uri)
                    retriever = it
                }
                var bmp: Bitmap? = r.getScaledFrameAtTime(ms * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 1280, 1280)
                    ?: r.getFrameAtTime(ms * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                bmp = bmp?.let { uprightFrame(it) }
                main.post {
                    if (bmp != null && !isDestroyed) marker.bitmap = bmp
                }
            } catch (e: Exception) {
                main.post {
                    Toast.makeText(this, "Couldn't show a frame: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    /** Some phones return the frame as stored (sideways); turn it upright if so. */
    private fun uprightFrame(b: Bitmap): Bitmap {
        val rot = session.rotation
        if (rot % 180 == 0) return b
        val storedLandscape = session.rawWidth > session.rawHeight
        val bmpLandscape = b.width > b.height
        if (storedLandscape != bmpLandscape) return b // already rotated
        val m = Matrix()
        m.postRotate(rot.toFloat())
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    private fun startAnalysis() {
        if (marker.ordered() == null) {
            Toast.makeText(this, "The 4 dots must make a court shape whose sides don't cross.", Toast.LENGTH_LONG).show()
            return
        }
        val h = marker.handles.copyOf()
        val changed = session.handles?.contentEquals(h) != true || session.flipNet != marker.flipNet
        session.handles = h
        session.flipNet = marker.flipNet
        if (changed) {
            session.analysed = false
            session.levelOverride = Double.NaN
        }
        SessionStore.save(this, session)
        SessionStore.setLastHandles(this, h)
        SessionStore.setLastKey(this, session.key)
        AnalysisJob.start(applicationContext, session)
        startActivity(Intent(this, AnalyzeActivity::class.java).putExtra(MainActivity.EXTRA_KEY, session.key))
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.execute {
            try {
                retriever?.release()
            } catch (_: Exception) {
            }
            retriever = null
        }
        worker.shutdown()
    }
}

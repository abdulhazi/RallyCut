package com.steve.rallycut.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Finds sharp, fast-decaying sound transients (shuttle hit candidates) in the 10 ms dB envelope. */
public final class HitFinder {
    private HitFinder() {
    }

    /** Each candidate is {timeSec, prominenceDb, levelDb}. */
    public static List<float[]> candidates(float[] d) {
        int n = d.length;
        float[] bg = background(d, 100, 25, 0.3);
        List<float[]> out = new ArrayList<>();
        int k = 3;
        while (k < n - 5) {
            float v = d[k];
            float rise = v - Math.min(d[k - 1], Math.min(d[k - 2], d[k - 3]));
            float prom = v - bg[k];
            if (rise >= 6.0f && prom >= 6.0f) {
                boolean ok = true;
                for (int j = Math.max(0, k - 5); j < k && ok; j++) if (!(d[j] < v)) ok = false;
                for (int j = k + 1; j < Math.min(n, k + 6) && ok; j++) if (!(d[j] <= v)) ok = false;
                if (ok) {
                    // impacts die away fast; squeaks, voices and music are sustained
                    float mn = Float.MAX_VALUE;
                    for (int j = k + 3; j < Math.min(n, k + 9); j++) mn = Math.min(mn, d[j]);
                    ok = mn <= v - 6.0f;
                }
                if (ok) {
                    out.add(new float[]{(float) (k * AudioEnvelope.HOP), prom, v});
                    k += 15; // 150 ms refractory
                    continue;
                }
            }
            k++;
        }
        return out;
    }

    static float[] background(float[] d, int win, int step, double pct) {
        int n = d.length;
        float[] bg = new float[n];
        for (int s = 0; s < n; s += step) {
            int lo = Math.max(0, s - win), hi = Math.min(n, s + win + 1);
            float[] seg = Arrays.copyOfRange(d, lo, hi);
            Arrays.sort(seg);
            float v = seg[(int) (pct * (seg.length - 1))];
            for (int i = s; i < Math.min(n, s + step); i++) bg[i] = v;
        }
        return bg;
    }
}

package com.steve.rallycut

import android.content.Context
import android.net.Uri
import com.steve.rallycut.core.RallyDetector
import kotlin.concurrent.thread

/** Turns stored features + session settings into the rally list. Fast; safe on the main thread. */
object Detection {
    fun visual(f: Features): RallyDetector.Visual? =
        if (f.videoOk && f.frameT.isNotEmpty())
            RallyDetector.visualCurve(f.frameT, f.frameNear, f.frameFar, f.frameBlobs, f.duration)
        else null

    fun params(s: Session): RallyDetector.Params {
        val p = RallyDetector.Params()
        p.sensitivity = s.sensitivity / 100.0
        p.preRoll = s.preRoll
        p.postRoll = s.postRoll
        p.levelOverride = s.levelOverride
        return p
    }

    fun run(s: Session, f: Features, vis: RallyDetector.Visual?) {
        val found = RallyDetector.detect(f.cands, vis, f.duration, params(s))
        s.rallies.clear()
        for (r in found) {
            s.rallies.add(
                RallyItem(
                    (r.start * 1000).toLong(), (r.end * 1000).toLong(), true, r.hits, r.confidence.toFloat()
                )
            )
        }
        s.edited = false
    }
}

/** Runs the long analysis in the background; survives the screen being recreated. */
object AnalysisJob {
    @Volatile var key: String? = null
    @Volatile var running = false
    @Volatile var audioProgress = 0f
    @Volatile var videoProgress = 0f
    @Volatile var error: String? = null
    @Volatile var finished = false
    @Volatile var noAudio = false
    @Volatile var videoFailed = false
    @Volatile private var cancelFlag = false
    @Volatile var startedAt = 0L
    @Volatile private var generation = 0

    val progress: Float get() = 0.2f * audioProgress + 0.8f * videoProgress

    fun cancel() {
        cancelFlag = true
    }

    fun start(appContext: Context, session: Session) {
        val myGen = ++generation
        val ctx = appContext.applicationContext
        val myKey = session.key
        key = myKey
        running = true
        finished = false
        error = null
        noAudio = false
        videoFailed = false
        audioProgress = 0f
        videoProgress = 0f
        cancelFlag = false
        startedAt = System.currentTimeMillis()
        val uri: Uri = session.uri
        val handles = session.handles ?: FloatArray(8)
        val flip = session.flipNet
        val rotation = session.rotation
        thread(name = "rally-analysis") {
            try {
                var audio: AudioPass.Result? = null
                var audioErr: Throwable? = null
                val at = thread(name = "rally-audio") {
                    try {
                        audio = AudioPass.run(ctx, uri, { if (generation == myGen) audioProgress = it }, { cancelFlag || generation != myGen })
                    } catch (t: Throwable) {
                        audioErr = t
                    }
                }
                var video: VideoPass.Result? = null
                var videoErr: Throwable? = null
                try {
                    video = VideoPass.run(ctx, uri, handles, flip, rotation, { if (generation == myGen) videoProgress = it }, { cancelFlag || generation != myGen })
                } catch (t: Throwable) {
                    videoErr = t
                }
                at.join()
                if (cancelFlag || generation != myGen) throw CancelledException()
                if (videoErr is CancelledException || audioErr is CancelledException) throw CancelledException()
                val a = audio
                val v = video
                if (a == null && v == null) {
                    throw IllegalStateException(
                        "Couldn't read this video" + ((videoErr ?: audioErr)?.message?.let { " ($it)" } ?: "")
                    )
                }
                noAudio = a == null
                videoFailed = v == null
                val duration = maxOf(a?.durationSec ?: 0.0, session.durationMs / 1000.0)
                val f = Features(
                    duration, v != null, a?.candidates ?: emptyList(),
                    v?.t ?: FloatArray(0), v?.near ?: FloatArray(0), v?.far ?: FloatArray(0), v?.blobs ?: FloatArray(0)
                )
                if (generation != myGen) throw CancelledException()
                SessionStore.saveFeatures(ctx, myKey, f)
                val s = SessionStore.load(ctx, myKey) ?: session
                s.videoOk = v != null
                s.levelOverride = Double.NaN
                Detection.run(s, f, Detection.visual(f))
                s.analysed = true
                SessionStore.save(ctx, s)
                audioProgress = 1f
                videoProgress = 1f
                finished = true
            } catch (_: CancelledException) {
                if (generation == myGen) error = "Cancelled"
            } catch (t: Throwable) {
                if (generation == myGen) error = t.message ?: t.javaClass.simpleName
            } finally {
                if (generation == myGen) running = false
            }
        }
    }
}

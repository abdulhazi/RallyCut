# RallyCut v3

Cuts a long badminton video into rallies. You review each rally (play, keep/remove, trim, split,
merge, add) and export one video of the rallies you kept.

## How detection works
1. **Shuttle hits (sound):** sharp, fast-decaying "thwack" sounds above 2 kHz. Your court is closest to
   the phone, so its hits are the loudest group of sounds; quieter hits (other courts) only help to
   extend a rally (soft serves, drop shots).
2. **Player motion (video):** movement inside the court you mark, split at the net. A rally needs
   both halves moving.
3. **Shuttle flight (video):** small, isolated moving dots in the court and the air above it.

Hits are chained into rallies (gaps up to 2.5 s, or 4.5 s when the court is still busy). Rallies need
3+ hits and players moving. Long stretches of strong court activity with missed sounds are added as
rallies too. Each rally gets 1.8 s before the first hit and after the last.

Core logic: `app/src/main/java/com/steve/rallycut/core` (plain Java, no Android calls).

## Build
GitHub Actions: `.github/workflows/build.yml` in the repo root unzips the newest `RallyCut-v*.zip`
and runs `gradle assembleDebug` (Gradle 8.7, JDK 17). The APK is in the run's artifacts.

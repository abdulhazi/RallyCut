package com.steve.rallycut.detect;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Turns what the video analysis measured (how much is moving on the court, and what the
 * chosen player's body is doing) into rallies with a score for the chosen player's play.
 * Pure Java so it can be tested on a computer.
 */
public final class PlayAnalyzer {

    private PlayAnalyzer() {}

    /** One entry per analysed frame (about 10 per second). */
    public static final class Series {
        public int n = 0;
        public long[] tMs = new long[4096];
        public float[] motion = new float[4096];     // share of the court area that is moving, 0..1
        public boolean[] tracked = new boolean[4096]; // chosen player seen in this frame
        public float[] px = new float[4096];          // player body centre (pixels)
        public float[] py = new float[4096];
        public float[] ph = new float[4096];          // player body height (pixels)
        public float[] wristUp = new float[4096];     // highest wrist above the head, in body heights
        public float[] wristSpeed = new float[4096];  // fastest wrist, body heights per second
        public float[] hipY = new float[4096];        // hip height in the picture (pixels)
        public boolean playerFound = false;           // false = could never find the chosen player

        public void add(long t, float m, boolean tr, float x, float y, float h,
                        float wUp, float wSpeed, float hip) {
            if (n == tMs.length) {
                int c = n * 2;
                tMs = Arrays.copyOf(tMs, c);
                motion = Arrays.copyOf(motion, c);
                tracked = Arrays.copyOf(tracked, c);
                px = Arrays.copyOf(px, c);
                py = Arrays.copyOf(py, c);
                ph = Arrays.copyOf(ph, c);
                wristUp = Arrays.copyOf(wristUp, c);
                wristSpeed = Arrays.copyOf(wristSpeed, c);
                hipY = Arrays.copyOf(hipY, c);
            }
            tMs[n] = t;
            motion[n] = m;
            tracked[n] = tr;
            px[n] = x;
            py[n] = y;
            ph[n] = h;
            wristUp[n] = wUp;
            wristSpeed[n] = wSpeed;
            hipY[n] = hip;
            n++;
        }
    }

    public static final class Params {
        public float sensitivity = 1.0f;   // >1 keeps more (lower motion threshold), <1 keeps less
        public long minRallyMs = 4000;
        public long mergeGapMs = 1500;
        public long padBeforeMs = 1000;
        public long padAfterMs = 1500;
    }

    public static final class Rally {
        public long startMs;       // clip start (padded)
        public long endMs;         // clip end (padded)
        public long playStartMs;
        public long playEndMs;
        public float meanMotion;
        public float trackedShare; // 0..1, how much of the rally the chosen player was followed
        public float swingPeak;    // fastest overhead swing
        public float jumpPeak;     // biggest jump, in body heights
        public float bodyPeak;     // fastest movement across the court
        public float effort;       // average movement
        public boolean smash;
        public boolean jump;
        public boolean scoredOnPlayer;
        public int score;          // 0..100

        public long durationMs() {
            return endMs - startMs;
        }
    }

    public static List<Rally> analyze(Series s, Params p, long durationMs) {
        List<Rally> out = new ArrayList<>();
        int n = s.n;
        if (n < 30) return out;

        // 1. smooth the court motion over about one second
        float[] sm = new float[n];
        int half = 5;
        double run = 0;
        int cnt = 0;
        int lo = 0, hi = -1;
        for (int i = 0; i < n; i++) {
            int a = Math.max(0, i - half), b = Math.min(n - 1, i + half);
            while (hi < b) { hi++; run += s.motion[hi]; cnt++; }
            while (lo < a) { run -= s.motion[lo]; lo++; cnt--; }
            sm[i] = (float) (run / cnt);
        }

        // 2. pick the level that best separates "play" from "dead time" for this video
        float thr = otsu(sm) / Math.max(0.2f, p.sensitivity);

        // 3. stretches above the level become rallies
        List<int[]> segs = new ArrayList<>();
        int start = -1;
        for (int i = 0; i <= n; i++) {
            boolean on = i < n && sm[i] > thr;
            if (on && start < 0) start = i;
            if (!on && start >= 0) {
                segs.add(new int[]{start, i - 1});
                start = -1;
            }
        }
        List<int[]> merged = new ArrayList<>();
        for (int[] g : segs) {
            if (!merged.isEmpty()) {
                int[] last = merged.get(merged.size() - 1);
                if (s.tMs[g[0]] - s.tMs[last[1]] <= p.mergeGapMs) {
                    last[1] = g[1];
                    continue;
                }
            }
            merged.add(g);
        }

        float[] bodySpeed = bodySpeed(s);

        for (int[] g : merged) {
            long ps = s.tMs[g[0]], pe = s.tMs[g[1]];
            if (pe - ps < p.minRallyMs) continue;
            Rally r = new Rally();
            r.playStartMs = ps;
            r.playEndMs = pe;
            r.startMs = Math.max(0, ps - p.padBeforeMs);
            r.endMs = pe + p.padAfterMs;
            if (durationMs > 0) r.endMs = Math.min(durationMs, r.endMs);
            if (!out.isEmpty()) {
                Rally prev = out.get(out.size() - 1);
                if (r.startMs < prev.endMs) r.startMs = prev.endMs;
            }
            if (r.endMs - r.startMs < 1000) continue;

            double mo = 0, eff = 0;
            int tr = 0, len = g[1] - g[0] + 1;
            for (int i = g[0]; i <= g[1]; i++) {
                mo += s.motion[i];
                if (!s.tracked[i]) continue;
                tr++;
                eff += bodySpeed[i];
                if (bodySpeed[i] > r.bodyPeak) r.bodyPeak = bodySpeed[i];
                // overhead swing: fast wrist while (or just after) the hand was above the head
                boolean up = false;
                for (int k = Math.max(g[0], i - 3); k <= i; k++) {
                    if (s.tracked[k] && s.wristUp[k] > 0.05f) { up = true; break; }
                }
                if (up && s.wristSpeed[i] > r.swingPeak) r.swingPeak = s.wristSpeed[i];
                // jump: hips clearly higher than 0.4 s before and after
                int a = i - 4, b = i + 4;
                if (a >= 0 && b < n && s.tracked[a] && s.tracked[b] && s.ph[i] > 1f) {
                    float j = ((s.hipY[a] + s.hipY[b]) * 0.5f - s.hipY[i]) / s.ph[i];
                    // both neighbours must agree, otherwise it is just walking up the picture
                    float ja = (s.hipY[a] - s.hipY[i]) / s.ph[i];
                    float jb = (s.hipY[b] - s.hipY[i]) / s.ph[i];
                    if (ja > 0.04f && jb > 0.04f && j > r.jumpPeak) r.jumpPeak = Math.min(j, 0.8f);
                }
            }
            r.meanMotion = (float) (mo / len);
            r.trackedShare = tr / (float) len;
            r.effort = tr > 0 ? (float) (eff / tr) : 0f;
            r.scoredOnPlayer = r.trackedShare >= 0.3f;
            r.smash = r.scoredOnPlayer && r.swingPeak >= 4.5f;
            r.jump = r.scoredOnPlayer && r.jumpPeak >= 0.2f;
            out.add(r);
        }

        // 4. score: rank each rally against the other rallies of the same video
        int m = out.size();
        if (m == 0) return out;
        float[] dur = new float[m], mot = new float[m];
        List<Rally> mine = new ArrayList<>();
        for (int i = 0; i < m; i++) {
            Rally r = out.get(i);
            dur[i] = r.playEndMs - r.playStartMs;
            mot[i] = r.meanMotion;
            if (r.scoredOnPlayer) mine.add(r);
        }
        float[] sw = new float[mine.size()], ju = new float[mine.size()],
                bo = new float[mine.size()], ef = new float[mine.size()];
        for (int i = 0; i < mine.size(); i++) {
            Rally r = mine.get(i);
            sw[i] = r.swingPeak;
            ju[i] = r.jumpPeak;
            bo[i] = r.bodyPeak;
            ef[i] = r.effort;
        }
        for (int i = 0; i < m; i++) {
            Rally r = out.get(i);
            float rallyScore = 0.5f * rank(dur, dur[i]) + 0.5f * rank(mot, mot[i]);
            if (r.scoredOnPlayer) {
                float my = 0.4f * rank(sw, r.swingPeak) + 0.25f * rank(ju, r.jumpPeak)
                        + 0.2f * rank(bo, r.bodyPeak) + 0.15f * rank(ef, r.effort);
                r.score = Math.round(100f * (0.7f * my + 0.3f * rallyScore));
            } else {
                r.score = Math.round(100f * 0.4f * rallyScore);
            }
        }
        return out;
    }

    /** Share of the time the chosen player was followed, 0..1. */
    public static float trackedShare(Series s) {
        if (s.n == 0) return 0f;
        int c = 0;
        for (int i = 0; i < s.n; i++) if (s.tracked[i]) c++;
        return c / (float) s.n;
    }

    private static float[] bodySpeed(Series s) {
        int n = s.n;
        float[] raw = new float[n];
        for (int i = 1; i < n; i++) {
            if (!s.tracked[i] || !s.tracked[i - 1] || s.ph[i] < 1f) continue;
            float dt = (s.tMs[i] - s.tMs[i - 1]) / 1000f;
            if (dt <= 0 || dt > 0.5f) continue;
            float dx = s.px[i] - s.px[i - 1], dy = s.py[i] - s.py[i - 1];
            raw[i] = Math.min(6f, (float) Math.sqrt(dx * dx + dy * dy) / s.ph[i] / dt);
        }
        float[] out = new float[n];
        for (int i = 0; i < n; i++) {
            float a = raw[Math.max(0, i - 1)], b = raw[i], c = raw[Math.min(n - 1, i + 1)];
            out[i] = (a + b + c) / 3f;
        }
        return out;
    }

    /** Fraction of values that are <= v (0..1). */
    private static float rank(float[] all, float v) {
        if (all.length <= 1) return 0.5f;
        int below = 0;
        for (float x : all) if (x < v) below++;
        return below / (float) (all.length - 1);
    }

    /** Otsu's method: the threshold that best splits the values into two groups. */
    static float otsu(float[] v) {
        float[] sorted = v.clone();
        Arrays.sort(sorted);
        float min = sorted[0];
        float max = sorted[(int) ((sorted.length - 1) * 0.99f)];
        if (max - min < 1e-6f) return max + 1f; // nothing ever moves: no rallies
        int bins = 64;
        int[] hist = new int[bins];
        for (float x : v) {
            int b = (int) ((Math.min(x, max) - min) / (max - min) * (bins - 1));
            hist[b]++;
        }
        long total = v.length;
        double sumAll = 0;
        for (int i = 0; i < bins; i++) sumAll += (double) i * hist[i];
        double sumB = 0;
        long wB = 0;
        double best = -1;
        int bestIdx = 0;
        for (int i = 0; i < bins; i++) {
            wB += hist[i];
            if (wB == 0) continue;
            long wF = total - wB;
            if (wF == 0) break;
            sumB += (double) i * hist[i];
            double mB = sumB / wB, mF = (sumAll - sumB) / wF;
            double between = (double) wB * wF * (mB - mF) * (mB - mF);
            if (between > best) {
                best = between;
                bestIdx = i;
            }
        }
        return min + (bestIdx + 0.5f) / (bins - 1) * (max - min);
    }
}

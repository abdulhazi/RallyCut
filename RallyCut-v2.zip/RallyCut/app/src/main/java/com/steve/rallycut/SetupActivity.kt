package com.steve.rallycut

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** The user marks their court (drag a box) and themselves (tap) on a frame of the video. */
class SetupActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URI = "uri"
        const val EXTRA_INDEX = "index"
        const val EXTRA_COURT = "court"
        const val EXTRA_TAP = "tap"
        const val EXTRA_PICK_MS = "pickMs"
    }

    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val generation = AtomicInteger(0)
    private var retriever: MediaMetadataRetriever? = null
    private var durationMs = 0L
    private var shownMs = 0L

    private lateinit var picker: PickerView
    private lateinit var status: TextView
    private lateinit var seek: SeekBar
    private lateinit var btnDone: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (12 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.fitsSystemWindows = true
        root.setPadding(pad, pad, pad, pad)

        val hint = TextView(this)
        hint.text = "1. Drag a box around YOUR court. Leave the other courts outside it.\n" +
            "2. Move the slider to a moment when you are on court, then tap on your body."
        root.addView(hint)

        picker = PickerView(this)
        root.addView(picker, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        status = TextView(this)
        status.setPadding(0, pad / 2, 0, 0)
        root.addView(status)

        seek = SeekBar(this)
        seek.isEnabled = false
        root.addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        btnDone = Button(this)
        btnDone.text = "Done"
        btnDone.isEnabled = false
        root.addView(btnDone, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(root)

        val uriText = intent.getStringExtra(EXTRA_URI)
        if (uriText == null) {
            finish()
            return
        }
        val uri = Uri.parse(uriText)
        val index = intent.getIntExtra(EXTRA_INDEX, 0)
        picker.court = intent.getFloatArrayExtra(EXTRA_COURT)
        picker.onChanged = { refresh() }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                if (fromUser) loadFrame(value * 500L, false)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                loadFrame(seek.progress * 500L, true)
            }
        })

        btnDone.setOnClickListener {
            val c = picker.court
            val t = picker.tap
            if (c != null && t != null) {
                val data = Intent()
                data.putExtra(EXTRA_INDEX, index)
                data.putExtra(EXTRA_COURT, c)
                data.putExtra(EXTRA_TAP, t)
                data.putExtra(EXTRA_PICK_MS, shownMs)
                setResult(Activity.RESULT_OK, data)
                finish()
            }
        }

        val ctx = applicationContext
        worker.execute {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(ctx, uri)
                val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                retriever = r
                main.post {
                    durationMs = d
                    seek.max = (d / 500L).toInt().coerceAtLeast(1)
                    seek.isEnabled = true
                    loadFrame(0L, true)
                }
            } catch (e: Exception) {
                main.post { status.text = "Could not open this video: ${e.message}" }
            }
        }
        refresh()
    }

    /** exact = the precise frame (slower); otherwise the nearest quick-to-load frame while sliding. */
    private fun loadFrame(ms: Long, exact: Boolean) {
        val gen = generation.incrementAndGet()
        picker.allowTap = false
        if (picker.tap != null) {
            picker.tap = null
            picker.invalidate()
        }
        refresh()
        worker.execute {
            if (gen != generation.get()) return@execute
            val r = retriever ?: return@execute
            val bmp: Bitmap? = try {
                r.getScaledFrameAtTime(
                    ms * 1000L,
                    if (exact) MediaMetadataRetriever.OPTION_CLOSEST else MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                    1280,
                    1280
                )
            } catch (e: Exception) {
                null
            }
            main.post {
                if (gen == generation.get() && bmp != null) {
                    picker.setFrame(bmp)
                    if (exact) {
                        shownMs = ms
                        picker.allowTap = true
                    }
                    refresh()
                }
            }
        }
    }

    private fun refresh() {
        val courtOk = picker.court != null
        val meOk = picker.tap != null
        val s = shownMs / 1000
        val time = String.format(Locale.US, "%d:%02d", s / 60, s % 60)
        status.text = "Court: " + (if (courtOk) "marked" else "not marked") +
            "    You: " + (if (meOk) "marked at $time" else if (picker.allowTap) "tap yourself" else "loading frame…")
        btnDone.isEnabled = courtOk && meOk
    }

    override fun onDestroy() {
        generation.incrementAndGet()
        main.removeCallbacksAndMessages(null)
        worker.execute {
            try {
                retriever?.release()
            } catch (_: Exception) {
            }
        }
        worker.shutdown()
        super.onDestroy()
    }
}

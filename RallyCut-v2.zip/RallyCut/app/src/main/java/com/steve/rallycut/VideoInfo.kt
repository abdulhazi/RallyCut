package com.steve.rallycut

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class VideoInfo(
    val width: Int,
    val height: Int,
    val rotation: Int,
    val durationMs: Long,
    val bitrate: Int,
    val fps: Int,
    val sizeBytes: Long
) {
    private val shortSide get() = min(width, height)
    private val longSide get() = max(width, height)

    private fun scaleFor(targetShortSide: Int): Float =
        if (targetShortSide in 1 until shortSide) targetShortSide.toFloat() / shortSide else 1f

    /** Height to hand to the exporter, or null to keep the original size. */
    fun outputHeight(targetShortSide: Int): Int? {
        val scale = scaleFor(targetShortSide)
        if (scale >= 1f) return null
        val displayedHeight = if (rotation == 90 || rotation == 270) width else height
        val h = (displayedHeight * scale).roundToInt()
        return max(2, h - h % 2)
    }

    /** quality: 0 = high, 1 = medium, 2 = low */
    fun targetBitrate(targetShortSide: Int, quality: Int, hevc: Boolean): Int {
        val scale = scaleFor(targetShortSide)
        val pixels = (shortSide * scale) * (longSide * scale)
        val bitsPerPixel = when (quality) {
            0 -> 0.12f
            1 -> 0.07f
            else -> 0.045f
        }
        var b = pixels * 30f * bitsPerPixel
        if (fps > 45) b *= 1.4f
        if (hevc) b *= 0.65f
        if (bitrate > 0) b = min(b, bitrate.toFloat())
        return max(500_000, b.toInt())
    }

    companion object {
        fun displayName(context: Context, uri: Uri): String {
            try {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c ->
                        if (c.moveToFirst()) {
                            val s = c.getString(0)
                            if (!s.isNullOrBlank()) return s
                        }
                    }
            } catch (_: Exception) {
            }
            return uri.lastPathSegment ?: "video"
        }

        fun load(context: Context, uri: Uri): VideoInfo {
            val r = MediaMetadataRetriever()
            var w = 0
            var h = 0
            var rot = 0
            var dur = 0L
            var br = 0
            try {
                r.setDataSource(context, uri)
                w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                br = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0
            } finally {
                try {
                    r.release()
                } catch (_: Exception) {
                }
            }
            if (w <= 0 || h <= 0) {
                w = 1920
                h = 1080
            }

            var fps = 30
            val ex = MediaExtractor()
            try {
                ex.setDataSource(context, uri, null)
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("video/") && f.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                        fps = try {
                            f.getInteger(MediaFormat.KEY_FRAME_RATE)
                        } catch (_: Exception) {
                            f.getFloat(MediaFormat.KEY_FRAME_RATE).roundToInt()
                        }
                        break
                    }
                }
            } catch (_: Exception) {
            } finally {
                ex.release()
            }

            var size = 0L
            try {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst() && !c.isNull(0)) size = c.getLong(0)
                }
            } catch (_: Exception) {
            }
            return VideoInfo(w, h, rot, dur, br, fps, size)
        }
    }
}

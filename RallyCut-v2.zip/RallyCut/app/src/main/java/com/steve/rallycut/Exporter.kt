package com.steve.rallycut

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File

/** Joins the chosen clips of one video into a single smaller file. Call from the main thread. */
@OptIn(UnstableApi::class)
class Exporter(private val context: Context) {

    private var transformer: Transformer? = null
    private val progressHolder = ProgressHolder()

    fun start(
        uri: Uri,
        clips: List<LongArray>, // each = [startMs, endMs]
        outputHeight: Int?,
        bitrate: Int,
        hevc: Boolean,
        outFile: File,
        onDone: (Exception?) -> Unit
    ) {
        val videoEffects = ArrayList<Effect>()
        if (outputHeight != null) videoEffects.add(Presentation.createForHeight(outputHeight))
        val effects = Effects(ArrayList<AudioProcessor>(), videoEffects)

        val items = ArrayList<EditedMediaItem>()
        for (c in clips) {
            val mediaItem = MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c[0])
                        .setEndPositionMs(c[1])
                        .build()
                )
                .build()
            items.add(EditedMediaItem.Builder(mediaItem).setEffects(effects).build())
        }

        val composition = Composition.Builder(listOf(EditedMediaItemSequence(items)))
            .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL)
            .build()

        val encoderFactory = DefaultEncoderFactory.Builder(context)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(bitrate).build()
            )
            .build()

        val t = Transformer.Builder(context)
            .setVideoMimeType(if (hevc) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    transformer = null
                    onDone(null)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    transformer = null
                    onDone(exportException)
                }
            })
            .build()
        transformer = t
        if (outFile.exists()) outFile.delete()
        t.start(composition, outFile.absolutePath)
    }

    /** 0..100 */
    fun progress(): Int {
        val t = transformer ?: return 0
        val state = t.getProgress(progressHolder)
        return if (state == Transformer.PROGRESS_STATE_AVAILABLE) progressHolder.progress else 0
    }

    fun cancel() {
        try {
            transformer?.cancel()
        } catch (_: Exception) {
        }
        transformer = null
    }

    companion object {
        /** Copies the finished file into Movies/RallyCut so it shows in the gallery. Background thread. */
        fun saveToGallery(context: Context, file: File, displayName: String) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/RallyCut")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val item = resolver.insert(collection, values)
                ?: throw IllegalStateException("Could not create the file in Movies/RallyCut")
            try {
                val out = resolver.openOutputStream(item)
                    ?: throw IllegalStateException("Could not open the output file")
                out.use { o -> file.inputStream().use { it.copyTo(o, 1 shl 20) } }
                val done = ContentValues()
                done.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(item, done, null, null)
            } catch (e: Exception) {
                try {
                    resolver.delete(item, null, null)
                } catch (_: Exception) {
                }
                throw e
            }
        }
    }
}

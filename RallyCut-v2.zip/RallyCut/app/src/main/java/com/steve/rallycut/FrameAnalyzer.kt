package com.steve.rallycut

import android.content.Context
import android.graphics.Bitmap
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import com.steve.rallycut.detect.PlayAnalyzer
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** What the user marked: court box and their own position, as 0..1 of the upright picture. */
class Setup(val court: FloatArray, val tap: FloatArray, val pickMs: Long)

/**
 * Watches the video about 10 times per second and measures
 *  - how much is moving inside the marked court (rallies vs dead time)
 *  - where the chosen player is and what their body is doing (pose model on a crop around them)
 * Run on a background thread.
 */
class FrameAnalyzer(
    private val context: Context,
    private val uri: Uri,
    private val rotation: Int,
    private val setup: Setup,
    private val cancel: AtomicBoolean,
    private val onProgress: (Float) -> Unit
) {
    private companion object {
        const val GW = 96
        const val GH = 54
        const val CROP = 400
        const val DIFF = 22
        const val STEP_US = 95_000L
        const val SIG_LIMIT = 0.3f
    }

    /** Reads pixels of a decoded frame in upright (display) coordinates. */
    private class Frame(image: Image, private val rot: Int) {
        private val crop = image.cropRect
        private val cw = crop.width()
        private val ch = crop.height()
        private val yb: ByteBuffer = image.planes[0].buffer
        private val yrs = image.planes[0].rowStride
        private val yps = image.planes[0].pixelStride
        private val ub: ByteBuffer = image.planes[1].buffer
        private val urs = image.planes[1].rowStride
        private val ups = image.planes[1].pixelStride
        private val vb: ByteBuffer = image.planes[2].buffer
        private val vrs = image.planes[2].rowStride
        private val vps = image.planes[2].pixelStride
        private val hi = if (image.format == 0x36) 1 else 0 // 10-bit video: use the high byte
        val w = if (rot == 90 || rot == 270) ch else cw
        val h = if (rot == 90 || rot == 270) cw else ch
        private var sx = 0
        private var sy = 0

        private fun map(dx: Int, dy: Int) {
            val x = if (dx < 0) 0 else if (dx >= w) w - 1 else dx
            val y = if (dy < 0) 0 else if (dy >= h) h - 1 else dy
            when (rot) {
                90 -> {
                    sx = y
                    sy = ch - 1 - x
                }
                180 -> {
                    sx = cw - 1 - x
                    sy = ch - 1 - y
                }
                270 -> {
                    sx = cw - 1 - y
                    sy = x
                }
                else -> {
                    sx = x
                    sy = y
                }
            }
            sx += crop.left
            sy += crop.top
        }

        private fun at(b: ByteBuffer, i: Int, fallback: Int): Int =
            if (i >= 0 && i < b.limit()) b.get(i).toInt() and 0xFF else fallback

        fun luma(dx: Int, dy: Int): Int {
            map(dx, dy)
            return at(yb, sy * yrs + sx * yps + hi, 0)
        }

        fun argb(dx: Int, dy: Int): Int {
            map(dx, dy)
            val c = at(yb, sy * yrs + sx * yps + hi, 16) - 16
            val d = at(ub, (sy / 2) * urs + (sx / 2) * ups + hi, 128) - 128
            val e = at(vb, (sy / 2) * vrs + (sx / 2) * vps + hi, 128) - 128
            var r = (298 * c + 459 * e + 128) shr 8
            var g = (298 * c - 55 * d - 136 * e + 128) shr 8
            var b = (298 * c + 541 * d + 128) shr 8
            if (r < 0) r = 0 else if (r > 255) r = 255
            if (g < 0) g = 0 else if (g > 255) g = 255
            if (b < 0) b = 0 else if (b > 255) b = 255
            return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
    }

    /** One body found by the pose model, in upright picture pixels. */
    private class Body(
        val cx: Float,
        val cy: Float,
        val h: Float,
        val side: Float,
        val sig: FloatArray,
        val wristUp: Float,
        val hipY: Float,
        val lOk: Boolean,
        val lx: Float,
        val ly: Float,
        val rOk: Boolean,
        val rx: Float,
        val ry: Float
    )

    private val detector = PoseDetection.getClient(
        PoseDetectorOptions.Builder()
            .setDetectorMode(PoseDetectorOptions.SINGLE_IMAGE_MODE)
            .build()
    )
    private val cropBitmap = Bitmap.createBitmap(CROP, CROP, Bitmap.Config.ARGB_8888)
    private val cropPixels = IntArray(CROP * CROP)

    private var grid = IntArray(GW * GH)
    private var prevGrid = IntArray(GW * GH)
    private val moving = BooleanArray(GW * GH)
    private var hasPrev = false

    private val series = PlayAnalyzer.Series()
    private var frameCount = 0

    // chosen player
    private var inited = false
    private var gaveUp = false
    private var initTries = 0
    private var lost = false
    private var cx = 0f
    private var cy = 0f
    private var bh = 0f
    private var refSig = FloatArray(3)
    private var misses = 0
    private var sincePose = 0
    private var lastOk = false
    private var lastWristUp = -1f
    private var lastHipY = 0f
    private var prevPoseMs = -1L
    private var pl = false
    private var plx = 0f
    private var ply = 0f
    private var pr = false
    private var prx = 0f
    private var pry = 0f

    /** @return the measurements, or null if cancelled. */
    fun run(): PlayAnalyzer.Series? {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) {
                    track = i
                    format = f
                    break
                }
            }
            if (track < 0 || format == null) throw IllegalStateException("No video track found")
            extractor.selectTrack(track)
            val mime = format.getString(MediaFormat.KEY_MIME)!!
            val durationUs =
                if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L
            format.setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
            )
            val dec = MediaCodec.createDecoderByType(mime)
            codec = dec
            dec.configure(format, null, null, 0)
            dec.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var lastUs = -1_000_000L
            var lastProgress = -1f

            while (!outputDone) {
                if (cancel.get()) return null
                if (!inputDone) {
                    val inIdx = dec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val buf = dec.getInputBuffer(inIdx)!!
                        val size = extractor.readSampleData(buf, 0)
                        if (size < 0) {
                            dec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = dec.dequeueOutputBuffer(info, 10_000)
                if (outIdx >= 0) {
                    val pts = info.presentationTimeUs
                    if (info.size > 0 && pts - lastUs >= STEP_US) {
                        val image = dec.getOutputImage(outIdx)
                        if (image != null) {
                            try {
                                if (image.format != 35 && image.format != 0x36) {
                                    throw IllegalStateException("Unsupported video colour format ${image.format}")
                                }
                                processFrame(Frame(image, rotation), pts / 1000)
                            } finally {
                                image.close()
                            }
                            lastUs = pts
                        }
                        if (durationUs > 0) {
                            val p = (pts.toFloat() / durationUs).coerceIn(0f, 1f)
                            if (p - lastProgress >= 0.005f) {
                                lastProgress = p
                                onProgress(p)
                            }
                        }
                    }
                    dec.releaseOutputBuffer(outIdx, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }
            series.playerFound = inited
            return series
        } finally {
            try {
                codec?.stop()
            } catch (_: Exception) {
            }
            try {
                codec?.release()
            } catch (_: Exception) {
            }
            extractor.release()
            try {
                detector.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun processFrame(frame: Frame, tMs: Long) {
        frameCount++
        val motion = courtMotion(frame)

        var tracked = false
        var wUp = -1f
        var wSpeed = 0f

        if (!gaveUp) {
            if (!inited) {
                if (tMs >= setup.pickMs) tracked = tryInit(frame, tMs)
            } else if (lost) {
                if (frameCount % 3 == 0) tracked = search(frame, tMs)
            } else {
                sincePose++
                if (lastOk && sincePose < 20 && localMotion(frame) == 0) {
                    // nothing moved where the player stands: they are still there
                    tracked = true
                } else {
                    val b = pose(frame, cx, cy, 2.2f * bh)
                    sincePose = 0
                    if (b != null && sigDist(b.sig, refSig) < SIG_LIMIT &&
                        b.h > 0.5f * bh && b.h < 2f * bh &&
                        hypot(b.cx - cx, b.cy - cy) < 1.2f * bh
                    ) {
                        wSpeed = accept(b, tMs, 0.2f)
                        tracked = true
                    } else {
                        lastOk = false
                        misses++
                        if (misses >= 15) lost = true
                    }
                }
            }
            if (tracked) wUp = lastWristUp
        }
        series.add(tMs, motion, tracked, cx, cy, bh, wUp, wSpeed, lastHipY)
    }

    // ---------- court motion ----------

    private fun courtMotion(frame: Frame): Float {
        val l = setup.court[0] * frame.w
        val t = setup.court[1] * frame.h
        val cellW = (setup.court[2] - setup.court[0]) * frame.w / GW
        val cellH = (setup.court[3] - setup.court[1]) * frame.h / GH
        val g = grid
        for (gy in 0 until GH) {
            val y0 = (t + (gy + 0.25f) * cellH).toInt()
            val y1 = (t + (gy + 0.75f) * cellH).toInt()
            for (gx in 0 until GW) {
                val x0 = (l + (gx + 0.25f) * cellW).toInt()
                val x1 = (l + (gx + 0.75f) * cellW).toInt()
                g[gy * GW + gx] =
                    (frame.luma(x0, y0) + frame.luma(x1, y0) + frame.luma(x0, y1) + frame.luma(x1, y1)) / 4
            }
        }
        var count = 0
        if (hasPrev) {
            val p = prevGrid
            for (i in 0 until GW * GH) {
                val m = abs(g[i] - p[i]) > DIFF
                moving[i] = m
                if (m) count++
            }
        }
        // swap buffers
        grid = prevGrid
        prevGrid = g
        hasPrev = true
        return count / (GW * GH).toFloat()
    }

    /** Moving cells where the player is standing; 1 if the player is outside the court box. */
    private fun localMotion(frame: Frame): Int {
        val l = setup.court[0] * frame.w
        val t = setup.court[1] * frame.h
        val cellW = (setup.court[2] - setup.court[0]) * frame.w / GW
        val cellH = (setup.court[3] - setup.court[1]) * frame.h / GH
        if (cellW <= 0f || cellH <= 0f) return 1
        val gx0 = ((cx - 0.6f * bh - l) / cellW).toInt()
        val gx1 = ((cx + 0.6f * bh - l) / cellW).toInt()
        val gy0 = ((cy - 0.7f * bh - t) / cellH).toInt()
        val gy1 = ((cy + 0.7f * bh - t) / cellH).toInt()
        if (gx1 < 0 || gy1 < 0 || gx0 >= GW || gy0 >= GH) return 1
        var count = 0
        for (gy in max(0, gy0)..min(GH - 1, gy1)) {
            for (gx in max(0, gx0)..min(GW - 1, gx1)) {
                if (moving[gy * GW + gx]) count++
            }
        }
        return count
    }

    // ---------- chosen player ----------

    private fun tryInit(frame: Frame, tMs: Long): Boolean {
        val tx = setup.tap[0] * frame.w
        val ty = setup.tap[1] * frame.h
        for (f in floatArrayOf(0.12f, 0.2f, 0.33f, 0.5f, 0.8f)) {
            val b = pose(frame, tx, ty, f * frame.h) ?: continue
            if (!fits(b)) continue
            if (abs(b.cx - tx) > 0.5f * b.h || abs(b.cy - ty) > 0.7f * b.h) continue
            inited = true
            cx = b.cx
            cy = b.cy
            bh = b.h
            refSig = b.sig.copyOf()
            accept(b, tMs, 1f)
            return true
        }
        initTries++
        if (initTries > 50) gaveUp = true // could not find a person where the user tapped
        return false
    }

    /** After losing the player: look at the places where something moves and compare shirt colour. */
    private fun search(frame: Frame, tMs: Long): Boolean {
        val tilesX = 8
        val tilesY = 6
        val tw = GW / tilesX
        val th = GH / tilesY
        val count = IntArray(tilesX * tilesY)
        val sumX = IntArray(tilesX * tilesY)
        val sumY = IntArray(tilesX * tilesY)
        for (gy in 0 until GH) {
            for (gx in 0 until GW) {
                if (!moving[gy * GW + gx]) continue
                val ti = min(tilesY - 1, gy / th) * tilesX + min(tilesX - 1, gx / tw)
                count[ti]++
                sumX[ti] += gx
                sumY[ti] += gy
            }
        }
        val l = setup.court[0] * frame.w
        val t = setup.court[1] * frame.h
        val cellW = (setup.court[2] - setup.court[0]) * frame.w / GW
        val cellH = (setup.court[3] - setup.court[1]) * frame.h / GH
        for (pick in 0 until 2) {
            var best = -1
            for (i in count.indices) if (count[i] >= 3 && (best < 0 || count[i] > count[best])) best = i
            if (best < 0) break
            val px = l + (sumX[best].toFloat() / count[best] + 0.5f) * cellW
            val py = t + (sumY[best].toFloat() / count[best] + 0.5f) * cellH
            count[best] = 0
            for (f in floatArrayOf(1f, 1.7f, 0.6f)) {
                val b = pose(frame, px, py, 2.2f * bh * f) ?: continue
                if (!fits(b)) continue
                if (sigDist(b.sig, refSig) >= SIG_LIMIT) continue
                lost = false
                cx = b.cx
                cy = b.cy
                bh = b.h
                prevPoseMs = -1L
                accept(b, tMs, 1f)
                return true
            }
        }
        return false
    }

    /** The body should fill a sensible part of the crop, otherwise the pose is probably a guess. */
    private fun fits(b: Body): Boolean = b.h > 0.25f * b.side && b.h < 0.95f * b.side

    /** Takes a pose as the player's new position. @return fastest wrist speed in body heights/second */
    private fun accept(b: Body, tMs: Long, sizeWeight: Float): Float {
        var speed = 0f
        if (prevPoseMs >= 0 && tMs - prevPoseMs in 1L..250L) {
            val dt = (tMs - prevPoseMs) / 1000f
            if (b.lOk && pl) speed = max(speed, hypot(b.lx - plx, b.ly - ply) / dt)
            if (b.rOk && pr) speed = max(speed, hypot(b.rx - prx, b.ry - pry) / dt)
            speed = min(speed, 12f)
        }
        prevPoseMs = tMs
        pl = b.lOk
        plx = b.lx
        ply = b.ly
        pr = b.rOk
        prx = b.rx
        pry = b.ry
        cx = b.cx
        cy = b.cy
        bh = (1f - sizeWeight) * bh + sizeWeight * b.h
        for (i in 0 until 3) refSig[i] = 0.98f * refSig[i] + 0.02f * b.sig[i]
        lastWristUp = b.wristUp
        lastHipY = b.hipY
        lastOk = true
        misses = 0
        return speed
    }

    private fun sigDist(a: FloatArray, b: FloatArray): Float {
        val d0 = a[0] - b[0]
        val d1 = a[1] - b[1]
        return 3f * sqrt(d0 * d0 + d1 * d1) + 0.5f * abs(a[2] - b[2])
    }

    /** Runs the pose model on a square crop of the frame. */
    private fun pose(frame: Frame, centerX: Float, centerY: Float, sideIn: Float): Body? {
        val side = max(96f, sideIn)
        val x0 = centerX - side / 2f
        val y0 = centerY - side / 2f
        val k = side / CROP
        for (j in 0 until CROP) {
            val dy = (y0 + (j + 0.5f) * k).toInt()
            val row = j * CROP
            for (i in 0 until CROP) {
                cropPixels[row + i] = frame.argb((x0 + (i + 0.5f) * k).toInt(), dy)
            }
        }
        cropBitmap.setPixels(cropPixels, 0, CROP, 0, 0, CROP, CROP)
        val found = try {
            Tasks.await(detector.process(InputImage.fromBitmap(cropBitmap, 0)))
        } catch (e: Exception) {
            return null
        }
        val ls = found.getPoseLandmark(PoseLandmark.LEFT_SHOULDER) ?: return null
        val rs = found.getPoseLandmark(PoseLandmark.RIGHT_SHOULDER) ?: return null
        val lh = found.getPoseLandmark(PoseLandmark.LEFT_HIP) ?: return null
        val rh = found.getPoseLandmark(PoseLandmark.RIGHT_HIP) ?: return null
        if (min(min(ls.inFrameLikelihood, rs.inFrameLikelihood), min(lh.inFrameLikelihood, rh.inFrameLikelihood)) < 0.5f) {
            return null
        }
        val smx = (ls.position.x + rs.position.x) / 2f
        val smy = (ls.position.y + rs.position.y) / 2f
        val hmx = (lh.position.x + rh.position.x) / 2f
        val hmy = (lh.position.y + rh.position.y) / 2f
        val torso = hypot(hmx - smx, hmy - smy)
        if (torso < 0.05f * CROP) return null
        val heightCrop = torso * 3.3f

        // shirt colour: average over the torso
        val bx0 = min(min(ls.position.x, rs.position.x), min(lh.position.x, rh.position.x))
        val bx1 = max(max(ls.position.x, rs.position.x), max(lh.position.x, rh.position.x))
        val by0 = min(ls.position.y, rs.position.y)
        val by1 = max(lh.position.y, rh.position.y)
        var sr = 0L
        var sg = 0L
        var sb = 0L
        var n = 0
        for (j in 0 until 10) {
            val y = (by0 + (by1 - by0) * (0.15f + 0.07f * j)).toInt()
            if (y < 0 || y >= CROP) continue
            for (i in 0 until 10) {
                val x = (bx0 + (bx1 - bx0) * (0.15f + 0.07f * i)).toInt()
                if (x < 0 || x >= CROP) continue
                val c = cropPixels[y * CROP + x]
                sr += (c shr 16) and 0xFF
                sg += (c shr 8) and 0xFF
                sb += c and 0xFF
                n++
            }
        }
        if (n == 0) return null
        val total = (sr + sg + sb + 1).toFloat()
        val sig = floatArrayOf(sr / total, sg / total, (sr + sg + sb) / (765f * n))

        val nose = found.getPoseLandmark(PoseLandmark.NOSE)
        val headY = if (nose != null && nose.inFrameLikelihood >= 0.3f) nose.position.y else smy - 0.25f * heightCrop
        val lw = found.getPoseLandmark(PoseLandmark.LEFT_WRIST)
        val rw = found.getPoseLandmark(PoseLandmark.RIGHT_WRIST)
        val lOk = lw != null && lw.inFrameLikelihood >= 0.5f
        val rOk = rw != null && rw.inFrameLikelihood >= 0.5f
        var wristUp = -1f
        var lx = 0f
        var ly = 0f
        var rx = 0f
        var ry = 0f
        if (lOk && lw != null) {
            wristUp = max(wristUp, (headY - lw.position.y) / heightCrop)
            lx = (lw.position.x - smx) / heightCrop
            ly = (lw.position.y - smy) / heightCrop
        }
        if (rOk && rw != null) {
            wristUp = max(wristUp, (headY - rw.position.y) / heightCrop)
            rx = (rw.position.x - smx) / heightCrop
            ry = (rw.position.y - smy) / heightCrop
        }
        return Body(
            x0 + (smx + hmx) / 2f * k,
            y0 + (smy + hmy) / 2f * k,
            heightCrop * k,
            side,
            sig,
            wristUp,
            y0 + hmy * k,
            lOk, lx, ly,
            rOk, rx, ry
        )
    }
}

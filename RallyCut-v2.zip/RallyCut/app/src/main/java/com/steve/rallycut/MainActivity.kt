package com.steve.rallycut

import android.app.Activity
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.steve.rallycut.detect.PlayAnalyzer
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {

    private class Job(val uri: Uri, val name: String) {
        var info: VideoInfo? = null
        var setup: Setup? = null
        var series: PlayAnalyzer.Series? = null
        var rallies: List<PlayAnalyzer.Rally> = emptyList()
        var selected: BooleanArray = BooleanArray(0)
        var error: String? = null
    }

    private val jobs = ArrayList<Job>()
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val cancelFlag = AtomicBoolean(false)
    private lateinit var exporter: Exporter

    private var busy = false
    private var exporting = false
    private var exportQueue: List<Job> = emptyList()
    private var exportIndex = 0
    private var exportTemp: File? = null
    private val exportResults = ArrayList<String>()
    private var previewEndMs = 0

    private lateinit var btnPick: Button
    private lateinit var txtVideos: TextView
    private lateinit var lblSensitivity: TextView
    private lateinit var seekSensitivity: SeekBar
    private lateinit var lblMinHits: TextView
    private lateinit var seekMinHits: SeekBar
    private lateinit var spinKeep: Spinner
    private lateinit var spinRes: Spinner
    private lateinit var spinQuality: Spinner
    private lateinit var chkHevc: CheckBox
    private lateinit var chkSkipReview: CheckBox
    private lateinit var btnAnalyze: Button
    private lateinit var progress: ProgressBar
    private lateinit var txtStatus: TextView
    private lateinit var btnCancel: Button
    private lateinit var videoView: VideoView
    private lateinit var rallyList: LinearLayout
    private lateinit var txtEstimate: TextView
    private lateinit var btnExport: Button

    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) {
                stopPreview()
                jobs.clear()
                for (u in uris) jobs.add(Job(u, VideoInfo.displayName(this, u)))
                txtVideos.text = jobs.joinToString("\n") { it.name }
                txtStatus.text = "Next: tap \"Mark court and me\" under each video."
                render()
                refreshButtons()
            }
        }

    private val setupLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == Activity.RESULT_OK && data != null) {
                val index = data.getIntExtra(SetupActivity.EXTRA_INDEX, -1)
                val court = data.getFloatArrayExtra(SetupActivity.EXTRA_COURT)
                val tap = data.getFloatArrayExtra(SetupActivity.EXTRA_TAP)
                if (index >= 0 && index < jobs.size && court != null && tap != null) {
                    val job = jobs[index]
                    job.setup = Setup(court, tap, data.getLongExtra(SetupActivity.EXTRA_PICK_MS, 0L))
                    // new marks: the old analysis no longer applies
                    job.series = null
                    job.rallies = emptyList()
                    job.selected = BooleanArray(0)
                    job.error = null
                    render()
                }
            }
        }

    private fun openSetup(index: Int) {
        if (busy) return
        stopPreview()
        val job = jobs[index]
        val intent = Intent(this, SetupActivity::class.java)
        intent.putExtra(SetupActivity.EXTRA_URI, job.uri.toString())
        intent.putExtra(SetupActivity.EXTRA_INDEX, index)
        // start from this video's court box, or the one drawn for another video (same tripod spot)
        val court = job.setup?.court ?: jobs.firstNotNullOfOrNull { it.setup?.court }
        if (court != null) intent.putExtra(SetupActivity.EXTRA_COURT, court)
        setupLauncher.launch(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        exporter = Exporter(applicationContext)

        btnPick = findViewById(R.id.btnPick)
        txtVideos = findViewById(R.id.txtVideos)
        lblSensitivity = findViewById(R.id.lblSensitivity)
        seekSensitivity = findViewById(R.id.seekSensitivity)
        lblMinHits = findViewById(R.id.lblMinHits)
        seekMinHits = findViewById(R.id.seekMinHits)
        spinKeep = findViewById(R.id.spinKeep)
        spinRes = findViewById(R.id.spinRes)
        spinQuality = findViewById(R.id.spinQuality)
        chkHevc = findViewById(R.id.chkHevc)
        chkSkipReview = findViewById(R.id.chkSkipReview)
        btnAnalyze = findViewById(R.id.btnAnalyze)
        progress = findViewById(R.id.progress)
        txtStatus = findViewById(R.id.txtStatus)
        btnCancel = findViewById(R.id.btnCancel)
        videoView = findViewById(R.id.videoView)
        rallyList = findViewById(R.id.rallyList)
        txtEstimate = findViewById(R.id.txtEstimate)
        btnExport = findViewById(R.id.btnExport)

        setupSpinner(
            spinKeep,
            listOf("All rallies (just cut the dead time)", "My top 5 rallies", "My top 10 rallies", "My top 20 rallies", "Only my smashes"),
            0
        )
        setupSpinner(spinRes, listOf("Original", "1080p", "720p", "480p"), 1)
        setupSpinner(spinQuality, listOf("High", "Medium", "Low"), 1)

        spinKeep.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (busy) return
                for (j in jobs) applyKeepRule(j)
                render()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        val estimateListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                updateEstimate()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        spinRes.onItemSelectedListener = estimateListener
        spinQuality.onItemSelectedListener = estimateListener
        chkHevc.setOnCheckedChangeListener { _, _ -> updateEstimate() }

        val seekListener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                updateLabels()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // re-detect instantly from the stored loudness data, no need to re-read the video
                if (!busy && jobs.any { it.series != null }) {
                    detectAll()
                    render()
                }
            }
        }
        seekSensitivity.setOnSeekBarChangeListener(seekListener)
        seekMinHits.setOnSeekBarChangeListener(seekListener)
        updateLabels()

        btnPick.setOnClickListener { picker.launch(arrayOf("video/*")) }
        btnAnalyze.setOnClickListener { analyze() }
        btnExport.setOnClickListener { startExport() }
        btnCancel.setOnClickListener { cancelWork() }
    }

    override fun onPause() {
        super.onPause()
        stopPreview()
    }

    override fun onDestroy() {
        cancelFlag.set(true)
        exporter.cancel()
        exportTemp?.delete()
        main.removeCallbacksAndMessages(null)
        worker.shutdownNow()
        super.onDestroy()
    }

    // ---------- settings ----------

    private fun setupSpinner(spinner: Spinner, items: List<String>, selected: Int) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.setSelection(selected)
    }

    private fun params(): PlayAnalyzer.Params {
        val p = PlayAnalyzer.Params()
        p.sensitivity = 0.5f + seekSensitivity.progress * 0.1f // 0..10 -> 0.5..1.5
        p.minRallyMs = (seekMinHits.progress + 2) * 1000L       // 0..10 -> 2..12 seconds
        return p
    }

    private fun updateLabels() {
        lblSensitivity.text =
            "Rally sensitivity: ${seekSensitivity.progress}/10 (raise if rallies are missed, lower if dead time gets in)"
        lblMinHits.text = "Shortest rally to keep: ${seekMinHits.progress + 2} seconds"
    }

    private fun targetShortSide(): Int = when (spinRes.selectedItemPosition) {
        1 -> 1080
        2 -> 720
        3 -> 480
        else -> 0
    }

    // ---------- analysis ----------

    private fun analyze() {
        if (busy || jobs.isEmpty()) return
        if (jobs.none { it.setup != null }) {
            txtStatus.text = "Mark your court and yourself on a video first."
            return
        }
        stopPreview()
        setBusy(true)
        cancelFlag.set(false)
        val list = ArrayList(jobs)
        val ctx = applicationContext
        worker.execute {
            for ((index, job) in list.withIndex()) {
                if (cancelFlag.get()) break
                val setup = job.setup ?: continue
                if (job.series != null) continue
                job.error = null
                try {
                    val info = VideoInfo.load(ctx, job.uri)
                    job.info = info
                    val label = "Watching ${index + 1}/${list.size}: ${job.name}"
                    main.post { showProgress(label, 0) }
                    val analyzer = FrameAnalyzer(ctx, job.uri, info.rotation, setup, cancelFlag) { p ->
                        main.post { showProgress(label, (p * 100).toInt()) }
                    }
                    job.series = analyzer.run()
                } catch (e: Exception) {
                    job.error = e.message ?: e.javaClass.simpleName
                }
            }
            main.post {
                val cancelled = cancelFlag.get()
                detectAll()
                setBusy(false)
                render()
                val found = jobs.sumOf { it.rallies.size }
                txtStatus.text = if (cancelled) "Cancelled" else "Found $found rallies"
                if (!cancelled && chkSkipReview.isChecked && found > 0) startExport()
            }
        }
    }

    private fun detectAll() {
        val p = params()
        for (job in jobs) {
            val series = job.series ?: continue
            job.rallies = PlayAnalyzer.analyze(series, p, job.info?.durationMs ?: 0L)
            applyKeepRule(job)
        }
    }

    private fun applyKeepRule(job: Job) {
        val n = job.rallies.size
        val sel = BooleanArray(n)
        when (val mode = spinKeep.selectedItemPosition) {
            0 -> sel.fill(true)
            4 -> for (i in 0 until n) sel[i] = job.rallies[i].smash
            else -> {
                val top = when (mode) {
                    1 -> 5
                    2 -> 10
                    else -> 20
                }
                val order = (0 until n).sortedByDescending { job.rallies[it].score }
                for (i in order.take(top)) sel[i] = true
            }
        }
        job.selected = sel
    }

    // ---------- list ----------

    private fun render() {
        rallyList.removeAllViews()
        val pad = (8 * resources.displayMetrics.density).toInt()
        for ((jobIndex, job) in jobs.withIndex()) {
            val header = TextView(this)
            header.setPadding(0, pad * 2, 0, pad)
            header.textSize = 16f
            val series = job.series
            val line: String
            if (job.error != null) {
                line = "Could not analyse: ${job.error}"
            } else if (job.setup == null) {
                line = "Not marked yet"
            } else if (series == null) {
                line = "Marked. Ready to find highlights."
            } else if (job.rallies.isEmpty()) {
                line = "No rallies found. Try raising the sensitivity."
            } else if (!series.playerFound) {
                line = "${job.rallies.size} rallies found. Could not find a person where you tapped, " +
                    "so rallies are ranked by movement only."
            } else {
                val share = (PlayAnalyzer.trackedShare(series) * 100).toInt()
                line = "${job.rallies.size} rallies found. Followed you $share% of the video."
            }
            header.text = job.name + "\n" + line
            rallyList.addView(header)

            val mark = TextView(this)
            mark.text = if (job.setup == null) "▣ Mark court and me" else "▣ Change court / me"
            mark.setPadding(0, pad, pad, pad)
            mark.setTextColor(0xFF2E7D32.toInt())
            mark.setOnClickListener { openSetup(jobIndex) }
            rallyList.addView(mark)

            for ((i, r) in job.rallies.withIndex()) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL

                val cb = CheckBox(this)
                cb.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                val tags = (if (r.smash) "  SMASH" else "") + (if (r.jump) "  JUMP" else "") +
                    (if (!r.scoredOnPlayer) "  (you not followed)" else "")
                cb.text = "${fmt(r.startMs)}  ·  ${r.durationMs() / 1000}s  ·  score ${r.score}$tags"
                cb.isChecked = job.selected[i]
                cb.setOnCheckedChangeListener { _, checked ->
                    job.selected[i] = checked
                    updateEstimate()
                }
                row.addView(cb)

                val play = TextView(this)
                play.text = "▶ Play"
                play.setPadding(pad * 2, pad, pad, pad)
                play.setOnClickListener { preview(job, r) }
                row.addView(play)

                rallyList.addView(row)
            }
        }
        updateEstimate()
        refreshButtons()
    }

    private fun updateEstimate() {
        var keptMs = 0L
        var totalMs = 0L
        var originalBytes = 0L
        var bytes = 0.0
        var count = 0
        val hevc = chkHevc.isChecked
        for (job in jobs) {
            val info = job.info ?: continue
            if (job.series == null) continue
            totalMs += info.durationMs
            originalBytes += info.sizeBytes
            var jobMs = 0L
            for ((i, r) in job.rallies.withIndex()) {
                if (job.selected[i]) {
                    jobMs += r.durationMs()
                    count++
                }
            }
            keptMs += jobMs
            val bps = info.targetBitrate(targetShortSide(), spinQuality.selectedItemPosition, hevc) + 128_000
            bytes += jobMs / 1000.0 * bps / 8.0
        }
        txtEstimate.text = if (totalMs == 0L) "" else
            "Keeping $count rallies: ${fmt(keptMs)} of ${fmt(totalMs)}. " +
                "Estimated size ${size(bytes.toLong())}" +
                (if (originalBytes > 0) " (originals ${size(originalBytes)})" else "")
        refreshButtons()
    }

    private fun refreshButtons() {
        btnPick.isEnabled = !busy
        btnAnalyze.isEnabled = !busy && jobs.any { it.setup != null }
        btnExport.isEnabled = !busy && jobs.any { j -> j.selected.any { it } }
    }

    // ---------- preview ----------

    private val previewWatcher = object : Runnable {
        override fun run() {
            try {
                if (videoView.visibility != View.VISIBLE) return
                if (videoView.isPlaying && videoView.currentPosition >= previewEndMs) {
                    videoView.pause()
                    return
                }
            } catch (_: Exception) {
                return
            }
            main.postDelayed(this, 200)
        }
    }

    private fun preview(job: Job, r: PlayAnalyzer.Rally) {
        if (busy) return
        main.removeCallbacks(previewWatcher)
        videoView.visibility = View.VISIBLE
        previewEndMs = r.endMs.toInt()
        videoView.setOnPreparedListener { mp ->
            mp.seekTo(r.startMs, MediaPlayer.SEEK_CLOSEST)
            videoView.start()
            main.postDelayed(previewWatcher, 500)
        }
        videoView.setVideoURI(job.uri)
    }

    private fun stopPreview() {
        main.removeCallbacks(previewWatcher)
        try {
            videoView.stopPlayback()
        } catch (_: Exception) {
        }
        videoView.visibility = View.GONE
    }

    // ---------- export ----------

    private fun startExport() {
        if (busy) return
        val queue = jobs.filter { j -> j.info != null && j.selected.any { it } }
        if (queue.isEmpty()) return
        stopPreview()
        exportQueue = queue
        exportIndex = 0
        exportResults.clear()
        exporting = true
        setBusy(true)
        exportCurrent(chkHevc.isChecked)
    }

    private fun exportCurrent(hevc: Boolean) {
        if (exportIndex >= exportQueue.size) {
            exporting = false
            setBusy(false)
            txtStatus.text = "Saved in Movies/RallyCut:\n" + exportResults.joinToString("\n") +
                "\n\nCheck the new videos before deleting the originals."
            return
        }
        val job = exportQueue[exportIndex]
        val info = job.info!!
        val clips = ArrayList<LongArray>()
        for ((i, r) in job.rallies.withIndex()) {
            if (job.selected[i]) clips.add(longArrayOf(r.startMs, r.endMs))
        }
        val dir = getExternalFilesDir(null) ?: cacheDir
        val temp = File(dir, "export_tmp.mp4")
        exportTemp = temp
        val label = "Exporting ${exportIndex + 1}/${exportQueue.size}: ${job.name}"
        showProgress(label, 0)
        val quality = spinQuality.selectedItemPosition
        val target = targetShortSide()
        try {
            exporter.start(
                job.uri,
                clips,
                info.outputHeight(target),
                info.targetBitrate(target, quality, hevc),
                hevc,
                temp
            ) { error ->
                main.removeCallbacks(exportTicker)
                if (!exporting) {
                    temp.delete()
                } else if (error != null) {
                    temp.delete()
                    if (hevc) {
                        // some phones cannot encode HEVC at this size: try again with H.264
                        exportCurrent(false)
                    } else {
                        exportResults.add("${job.name}: FAILED (${error.message})")
                        exportIndex++
                        exportCurrent(chkHevc.isChecked)
                    }
                } else {
                    finishExport(job, temp)
                }
            }
        } catch (e: Exception) {
            temp.delete()
            exportResults.add("${job.name}: FAILED (${e.message})")
            exportIndex++
            exportCurrent(chkHevc.isChecked)
            return
        }
        exportLabel = label
        main.postDelayed(exportTicker, 500)
    }

    private var exportLabel = ""
    private val exportTicker = object : Runnable {
        override fun run() {
            if (!exporting) return
            showProgress(exportLabel, exporter.progress())
            main.postDelayed(this, 500)
        }
    }

    private fun finishExport(job: Job, temp: File) {
        showProgress("Saving ${job.name}", 100)
        val base = job.name.substringBeforeLast('.')
        val outName = "${base}_highlights.mp4"
        val ctx = applicationContext
        worker.execute {
            var line: String
            try {
                val bytes = temp.length()
                Exporter.saveToGallery(ctx, temp, outName)
                val original = job.info?.sizeBytes ?: 0L
                line = "$outName: ${size(bytes)}" + if (original > 0) " (was ${size(original)})" else ""
            } catch (e: Exception) {
                line = "${job.name}: FAILED to save (${e.message})"
            }
            temp.delete()
            main.post {
                if (exporting) {
                    exportResults.add(line)
                    exportIndex++
                    exportCurrent(chkHevc.isChecked)
                }
            }
        }
    }

    private fun cancelWork() {
        cancelFlag.set(true)
        if (exporting) {
            exporting = false
            main.removeCallbacks(exportTicker)
            exporter.cancel()
            exportTemp?.delete()
            setBusy(false)
            txtStatus.text = "Export cancelled"
        }
    }

    // ---------- helpers ----------

    private fun setBusy(b: Boolean) {
        busy = b
        progress.visibility = if (b) View.VISIBLE else View.GONE
        btnCancel.visibility = if (b) View.VISIBLE else View.GONE
        seekSensitivity.isEnabled = !b
        seekMinHits.isEnabled = !b
        spinKeep.isEnabled = !b
        spinRes.isEnabled = !b
        spinQuality.isEnabled = !b
        chkHevc.isEnabled = !b
        if (b) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        refreshButtons()
    }

    private fun showProgress(label: String, percent: Int) {
        if (!busy) return
        progress.progress = percent
        txtStatus.text = "$label  $percent%"
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%d:%02d", m, sec)
    }

    private fun size(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb >= 1024) String.format(Locale.US, "%.2f GB", mb / 1024.0)
        else String.format(Locale.US, "%.0f MB", mb)
    }
}

package com.steve.rallycut

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Shows one video frame. Drag = draw the court box. Tap = mark yourself. */
@SuppressLint("ViewConstructor")
class PickerView(context: Context) : View(context) {

    var court: FloatArray? = null // left, top, right, bottom as 0..1 of the picture
    var tap: FloatArray? = null   // x, y as 0..1 of the picture
    var allowTap = false
    var onChanged: (() -> Unit)? = null

    private var bitmap: Bitmap? = null
    private val dest = RectF()
    private val density = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val courtPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.GREEN
        strokeWidth = 3f * density
    }
    private val tapPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.YELLOW
        strokeWidth = 3f * density
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.YELLOW
    }

    private var downX = 0f
    private var downY = 0f
    private var downNx = 0f
    private var downNy = 0f
    private var dragging = false

    fun setFrame(b: Bitmap) {
        bitmap = b
        invalidate()
    }

    private fun imageRect(): RectF? {
        val b = bitmap ?: return null
        if (width == 0 || height == 0) return null
        val scale = min(width / b.width.toFloat(), height / b.height.toFloat())
        val w = b.width * scale
        val h = b.height * scale
        dest.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
        return dest
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val b = bitmap ?: return
        val r = imageRect() ?: return
        canvas.drawBitmap(b, null, r, bitmapPaint)
        val c = court
        if (c != null) {
            canvas.drawRect(
                r.left + c[0] * r.width(), r.top + c[1] * r.height(),
                r.left + c[2] * r.width(), r.top + c[3] * r.height(), courtPaint
            )
        }
        val t = tap
        if (t != null) {
            val x = r.left + t[0] * r.width()
            val y = r.top + t[1] * r.height()
            canvas.drawCircle(x, y, 16f * density, tapPaint)
            canvas.drawCircle(x, y, 3f * density, dotPaint)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val r = imageRect() ?: return false
        val nx = ((e.x - r.left) / r.width()).coerceIn(0f, 1f)
        val ny = ((e.y - r.top) / r.height()).coerceIn(0f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                downNx = nx
                downNy = ny
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && hypot(e.x - downX, e.y - downY) > slop) dragging = true
                if (dragging) {
                    court = floatArrayOf(min(downNx, nx), min(downNy, ny), max(downNx, nx), max(downNy, ny))
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    val c = court
                    if (c != null && (c[2] - c[0] < 0.05f || c[3] - c[1] < 0.05f)) court = null
                } else if (allowTap) {
                    tap = floatArrayOf(nx, ny)
                }
                dragging = false
                invalidate()
                onChanged?.invoke()
            }
        }
        return true
    }
}

# RallyCut v4

Cuts a long badminton video into rallies. You review each rally (play, keep/remove, trim, split,
merge, add) and export one video of the rallies you kept.

## How detection works (v4)
Badminton repeats a cycle: everyone stands still for the serve (SETUP), the rally is played (RALLY),
then players scatter, fetch the shuttle and walk back (BREAK).

1. You mark the play area once per video (a 4-corner shape covering where your court's players move).
2. Every 0.1 s the app measures, inside that area:
   - how much of the picture changed (movement),
   - how the players' silhouettes changed (against a background picture built from the video itself),
   - whether players are walking somewhere (silhouettes 3 s apart differ a lot) or moving back and
     forth on the spot (rally).
3. Sharp "thwack" sounds (shuttle hits) are found in the soundtrack.
4. A Viterbi pass finds the most likely SETUP -> RALLY -> BREAK sequence with minimum lengths
   (setup 0.6 s, rally 2 s, break 2.5 s). Hit sounds then pin down each rally's start and end.

Tested on a real 3-minute doubles clip: all 13 rallies found, no clips from between rallies
(one unclear net-tapping moment shown as a short rally).

Core logic: `app/src/main/java/com/steve/rallycut/core` (plain Java, no Android calls).

## Build
GitHub Actions: `.github/workflows/build.yml` in the repo root unzips the newest `RallyCut-v*.zip`
and runs `gradle assembleDebug` (Gradle 8.7, JDK 17). The APK is in the run's artifacts.

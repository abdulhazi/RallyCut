package com.steve.rallycut

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.abs

/** Basic facts about the picked video. Width/height are the stored (unrotated) frame size. */
class VideoInfo(
    val name: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val rawWidth: Int,
    val rawHeight: Int,
    val rotation: Int
) {
    companion object {
        fun load(context: Context, uri: Uri): VideoInfo {
            var name = "video"
            var size = -1L
            try {
                context.contentResolver.query(
                    uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null
                )?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
            } catch (_: Exception) {
            }
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(context, uri)
                val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rot = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                return VideoInfo(name, size, dur, w, h, ((rot % 360) + 360) % 360)
            } finally {
                try {
                    mmr.release()
                } catch (_: Exception) {
                }
            }
        }
    }
}

class RallyItem(
    var startMs: Long,
    var endMs: Long,
    var keep: Boolean,
    var hits: Int,
    var confidence: Float,
    var manual: Boolean = false
) {
    val lengthMs: Long get() = endMs - startMs
}

/** Everything about one video: court marking, detection settings and the rally list (with user edits). */
class Session(
    val key: String,
    val uri: Uri,
    val name: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val rawWidth: Int,
    val rawHeight: Int,
    val rotation: Int
) {
    /** Four play-area corners, normalised 0..1 in the upright (display) frame, in any order. */
    var handles: FloatArray? = null
    var sensitivity = 50
    var preRoll = 1.8
    var postRoll = 1.8
    var edited = false
    var analysed = false
    var videoOk = true
    val rallies = ArrayList<RallyItem>()

    val displayWidth: Int get() = if (rotation % 180 != 0) rawHeight else rawWidth
    val displayHeight: Int get() = if (rotation % 180 != 0) rawWidth else rawHeight

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("key", key)
        o.put("uri", uri.toString())
        o.put("name", name)
        o.put("size", sizeBytes)
        o.put("duration", durationMs)
        o.put("rawW", rawWidth)
        o.put("rawH", rawHeight)
        o.put("rotation", rotation)
        handles?.let { h ->
            val a = JSONArray()
            for (v in h) a.put(v.toDouble())
            o.put("handles", a)
        }
        o.put("sensitivity", sensitivity)
        o.put("pre", preRoll)
        o.put("post", postRoll)
        o.put("edited", edited)
        o.put("analysed", analysed)
        o.put("videoOk", videoOk)
        val ra = JSONArray()
        for (r in rallies) {
            val j = JSONObject()
            j.put("s", r.startMs)
            j.put("e", r.endMs)
            j.put("k", r.keep)
            j.put("h", r.hits)
            j.put("c", r.confidence.toDouble())
            j.put("m", r.manual)
            ra.put(j)
        }
        o.put("rallies", ra)
        return o
    }

    companion object {
        fun keyFor(uri: Uri, size: Long): String = "v" + abs(uri.toString().hashCode()) + "_" + size

        fun fromJson(o: JSONObject): Session {
            val s = Session(
                o.getString("key"), Uri.parse(o.getString("uri")), o.getString("name"),
                o.getLong("size"), o.getLong("duration"), o.getInt("rawW"), o.getInt("rawH"), o.getInt("rotation")
            )
            val h = o.optJSONArray("handles")
            if (h != null && h.length() == 8) {
                s.handles = FloatArray(8) { h.getDouble(it).toFloat() }
            }
            s.sensitivity = o.optInt("sensitivity", 50)
            s.preRoll = o.optDouble("pre", 1.8)
            s.postRoll = o.optDouble("post", 1.8)
            s.edited = o.optBoolean("edited", false)
            s.analysed = o.optBoolean("analysed", false)
            s.videoOk = o.optBoolean("videoOk", true)
            val ra = o.optJSONArray("rallies")
            if (ra != null) {
                for (i in 0 until ra.length()) {
                    val j = ra.getJSONObject(i)
                    s.rallies.add(
                        RallyItem(
                            j.getLong("s"), j.getLong("e"), j.optBoolean("k", true), j.optInt("h", 0),
                            j.optDouble("c", 0.0).toFloat(), j.optBoolean("m", false)
                        )
                    )
                }
            }
            return s
        }
    }
}

/** Analysis output kept on disk so the slider can re-detect instantly. */
class Features(
    val duration: Double,
    val videoOk: Boolean,
    val hits: FloatArray,   // hit-sound times (s)
    val mov: FloatArray,    // per video frame, 10 a second
    val step: FloatArray,
    val net: FloatArray
)

object SessionStore {
    private const val PREFS = "rallycut"
    private const val MAGIC = 0x52435634 // "RCV4"

    private fun dir(context: Context): File = File(context.filesDir, "sessions").apply { mkdirs() }

    fun save(context: Context, s: Session) {
        val f = File(dir(context), s.key + ".json")
        val tmp = File(dir(context), s.key + ".json.tmp")
        tmp.writeText(s.toJson().toString())
        if (!tmp.renameTo(f)) {
            f.writeText(s.toJson().toString())
            tmp.delete()
        }
    }

    fun load(context: Context, key: String): Session? {
        val f = File(dir(context), "$key.json")
        if (!f.exists()) return null
        return try {
            Session.fromJson(JSONObject(f.readText()))
        } catch (_: Exception) {
            null
        }
    }

    fun delete(context: Context, key: String) {
        File(dir(context), "$key.json").delete()
        File(dir(context), "$key.feat").delete()
        if (lastKey(context) == key) setLastKey(context, null)
    }

    fun saveFeatures(context: Context, key: String, f: Features) {
        val file = File(dir(context), "$key.feat")
        DataOutputStream(BufferedOutputStream(FileOutputStream(file), 1 shl 16)).use { out ->
            out.writeInt(MAGIC)
            out.writeDouble(f.duration)
            out.writeBoolean(f.videoOk)
            out.writeInt(f.hits.size)
            for (h in f.hits) out.writeFloat(h)
            out.writeInt(f.mov.size)
            for (i in f.mov.indices) {
                out.writeFloat(f.mov[i])
                out.writeFloat(f.step[i])
                out.writeFloat(f.net[i])
            }
        }
    }

    fun hasFeatures(context: Context, key: String): Boolean = File(dir(context), "$key.feat").exists()

    fun loadFeatures(context: Context, key: String): Features? {
        val file = File(dir(context), "$key.feat")
        if (!file.exists()) return null
        return try {
            DataInputStream(BufferedInputStream(FileInputStream(file), 1 shl 16)).use { inp ->
                if (inp.readInt() != MAGIC) return null
                val duration = inp.readDouble()
                val videoOk = inp.readBoolean()
                val nh = inp.readInt()
                val hits = FloatArray(nh)
                for (i in 0 until nh) hits[i] = inp.readFloat()
                val nf = inp.readInt()
                val mov = FloatArray(nf)
                val step = FloatArray(nf)
                val net = FloatArray(nf)
                for (i in 0 until nf) {
                    mov[i] = inp.readFloat()
                    step[i] = inp.readFloat()
                    net[i] = inp.readFloat()
                }
                Features(duration, videoOk, hits, mov, step, net)
            }
        } catch (_: Exception) {
            null
        }
    }

    fun lastKey(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("lastKey", null)

    fun setLastKey(context: Context, key: String?) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("lastKey", key).apply()
    }

    /** Play-area corners from the last video (the tripod usually stands in a similar place). */
    fun lastHandles(context: Context): FloatArray? {
        val s = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("lastArea", null) ?: return null
        val parts = s.split(",")
        if (parts.size != 8) return null
        return try {
            FloatArray(8) { parts[it].toFloat() }
        } catch (_: Exception) {
            null
        }
    }

    fun setLastHandles(context: Context, h: FloatArray) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("lastArea", h.joinToString(",")).apply()
    }
}

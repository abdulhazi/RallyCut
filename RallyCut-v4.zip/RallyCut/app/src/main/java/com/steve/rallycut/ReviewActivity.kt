package com.steve.rallycut

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.steve.rallycut.ui.RallyAdapter
import com.steve.rallycut.ui.ThumbLoader
import com.steve.rallycut.ui.TimelineView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class ReviewActivity : AppCompatActivity() {

    private enum class Mode { NONE, SINGLE, SEQUENCE }

    private lateinit var session: Session
    private lateinit var features: Features

    private lateinit var player: ExoPlayer
    private lateinit var timeline: TimelineView
    private lateinit var sensSeek: SeekBar
    private lateinit var sensValue: TextView
    private lateinit var summary: TextView
    private lateinit var notice: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: RallyAdapter
    private lateinit var thumbs: ThumbLoader
    private lateinit var editPanel: LinearLayout
    private lateinit var editTitle: TextView
    private lateinit var playKept: MaterialButton

    private val main = Handler(Looper.getMainLooper())
    private var selected: RallyItem? = null
    private var mode = Mode.NONE
    private var playing: RallyItem? = null
    private var ready = false

    private val deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) originalDeleted()
        else toast("The original video was kept.")
    }

    private val poll = object : Runnable {
        override fun run() {
            onTick()
            main.postDelayed(this, 50)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review)
        val key = intent.getStringExtra(MainActivity.EXTRA_KEY)
        val s = key?.let { SessionStore.load(this, it) }
        val f = key?.let { SessionStore.loadFeatures(this, it) }
        if (s == null || f == null) {
            if (s != null) {
                startActivity(Intent(this, CourtActivity::class.java).putExtra(MainActivity.EXTRA_KEY, s.key))
            }
            finish()
            return
        }
        session = s
        features = f
        SessionStore.setLastKey(this, s.key)

        val playerView = findViewById<PlayerView>(R.id.player)
        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        player.setMediaItem(MediaItem.fromUri(s.uri))
        player.prepare()

        timeline = findViewById(R.id.timeline)
        timeline.durationMs = s.durationMs
        timeline.activity = downsample(activityCurve(), 400)
        timeline.onSeek = { ms ->
            if (mode == Mode.SINGLE) mode = Mode.NONE
            player.seekTo(ms)
            session.rallies.firstOrNull { ms >= it.startMs && ms <= it.endMs }?.let { select(it, false) }
        }

        sensSeek = findViewById(R.id.sensitivity)
        sensValue = findViewById(R.id.sensValue)
        summary = findViewById(R.id.summary)
        notice = findViewById(R.id.notice)
        editPanel = findViewById(R.id.editPanel)
        editTitle = findViewById(R.id.editTitle)
        playKept = findViewById(R.id.playKept)

        thumbs = ThumbLoader(applicationContext, s.uri)
        adapter = RallyAdapter(session.rallies, thumbs, { select(it, true) }, { changed() })
        list = findViewById(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        sensSeek.progress = s.sensitivity
        sensValue.text = s.sensitivity.toString()
        sensSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                sensValue.text = progress.toString()
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}

            override fun onStopTrackingTouch(sb: SeekBar) {
                val v = sb.progress
                if (v == session.sensitivity) return
                confirmRedetect({ session.sensitivity = v }, {
                    sb.progress = session.sensitivity
                })
            }
        })

        findViewById<MaterialButton>(R.id.export).setOnClickListener { showExport() }
        playKept.setOnClickListener { togglePlayKept() }
        findViewById<MaterialButton>(R.id.dropShort).setOnClickListener {
            var n = 0
            for (r in session.rallies) if (r.keep && r.lengthMs < 5000) {
                r.keep = false
                n++
            }
            adapter.notifyDataSetChanged()
            changed()
            toast(if (n == 0) "No kept rallies shorter than 5 s." else "Removed $n short rallies.")
        }
        findViewById<MaterialButton>(R.id.keepAll).setOnClickListener {
            for (r in session.rallies) r.keep = true
            adapter.notifyDataSetChanged()
            changed()
        }
        findViewById<MaterialButton>(R.id.addRally).setOnClickListener { addRallyAtPlayhead() }
        findViewById<MaterialButton>(R.id.remark).setOnClickListener {
            startActivity(Intent(this, CourtActivity::class.java).putExtra(MainActivity.EXTRA_KEY, session.key))
            finish()
        }

        findViewById<MaterialButton>(R.id.editClose).setOnClickListener { select(null, false) }
        findViewById<MaterialButton>(R.id.startM1).setOnClickListener { moveStart(-1000) }
        findViewById<MaterialButton>(R.id.startM02).setOnClickListener { moveStart(-200) }
        findViewById<MaterialButton>(R.id.startP02).setOnClickListener { moveStart(200) }
        findViewById<MaterialButton>(R.id.startP1).setOnClickListener { moveStart(1000) }
        findViewById<MaterialButton>(R.id.startHere).setOnClickListener {
            selected?.let { moveStart(player.currentPosition - it.startMs) }
        }
        findViewById<MaterialButton>(R.id.endM1).setOnClickListener { moveEnd(-1000) }
        findViewById<MaterialButton>(R.id.endM02).setOnClickListener { moveEnd(-200) }
        findViewById<MaterialButton>(R.id.endP02).setOnClickListener { moveEnd(200) }
        findViewById<MaterialButton>(R.id.endP1).setOnClickListener { moveEnd(1000) }
        findViewById<MaterialButton>(R.id.endHere).setOnClickListener {
            selected?.let { moveEnd(player.currentPosition - it.endMs) }
        }
        findViewById<MaterialButton>(R.id.split).setOnClickListener { splitAtPlayhead() }
        findViewById<MaterialButton>(R.id.merge).setOnClickListener { mergeWithNext() }
        findViewById<MaterialButton>(R.id.delete).setOnClickListener { deleteSelected() }

        when {
            !s.videoOk || !f.videoOk -> showNotice("This phone couldn't read the video frames, so only the hit sounds were used. Results will be rougher.")
            f.hits.isEmpty() -> showNotice("No hit sounds found in this video, so only player movement was used.")
        }
        ready = true
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (ready) main.post(poll)
    }

    override fun onPause() {
        super.onPause()
        main.removeCallbacks(poll)
        if (ready) {
            player.pause()
            SessionStore.save(this, session)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (ready) {
            player.release()
            thumbs.close()
        }
    }

    // ------------------------------------------------------------------ state

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun showNotice(msg: String) {
        notice.text = msg
        notice.visibility = View.VISIBLE
    }

    /** Rally likelihood over the video, for the faint curve on the timeline (no change to the list). */
    private fun activityCurve(): FloatArray {
        val copy = Session(
            session.key, session.uri, session.name, session.sizeBytes, session.durationMs,
            session.rawWidth, session.rawHeight, session.rotation
        )
        copy.sensitivity = session.sensitivity
        return Detection.run(copy, features)
    }

    private fun downsample(v: FloatArray, n: Int): FloatArray {
        if (v.isEmpty()) return FloatArray(0)
        val out = FloatArray(n)
        for (i in 0 until n) {
            val a = (i.toLong() * v.size / n).toInt()
            val b = maxOf(a + 1, ((i + 1).toLong() * v.size / n).toInt()).coerceAtMost(v.size)
            var m = 0f
            for (j in a until b) m = maxOf(m, v[j])
            out[i] = m
        }
        return out
    }

    private fun refresh() {
        timeline.rallies = session.rallies
        timeline.selected = selected
        val kept = session.rallies.filter { it.keep }
        val keptMs = kept.sumOf { it.lengthMs }
        summary.text = "${session.rallies.size} rallies found · keeping ${kept.size} " +
                "(${Fmt.clock(keptMs)} of ${Fmt.clock(session.durationMs)})"
        val r = selected
        if (r != null) {
            val idx = session.rallies.indexOf(r)
            editTitle.text = "Rally ${idx + 1}: ${Fmt.clockTenths(r.startMs)} – ${Fmt.clockTenths(r.endMs)} (${Fmt.seconds(r.lengthMs)})"
        }
    }

    /** A user edit (keep/remove, trim, add...) happened. */
    private fun changed() {
        session.edited = true
        SessionStore.save(this, session)
        refresh()
    }

    private fun afterEdit(scrollTo: RallyItem?) {
        session.rallies.sortBy { it.startMs }
        adapter.selected = selected
        adapter.notifyDataSetChanged()
        changed()
        if (scrollTo != null) {
            val i = session.rallies.indexOf(scrollTo)
            if (i >= 0) list.scrollToPosition(i)
        }
    }

    private fun confirmRedetect(apply: () -> Unit, onCancel: (() -> Unit)?) {
        if (!session.edited) {
            apply()
            redetect()
            return
        }
        var done = false
        MaterialAlertDialogBuilder(this)
            .setTitle("Find rallies again?")
            .setMessage("Your manual changes (keep/remove, trims, added rallies) will be replaced by the new detection.")
            .setPositiveButton("Find again") { _, _ ->
                done = true
                apply()
                redetect()
            }
            .setNegativeButton("Cancel", null)
            .setOnDismissListener { if (!done) onCancel?.invoke() }
            .show()
    }

    private fun redetect() {
        stopPlayback()
        timeline.activity = downsample(Detection.run(session, features), 400)
        select(null, false)
        adapter.notifyDataSetChanged()
        SessionStore.save(this, session)
        refresh()
        list.scrollToPosition(0)
    }

    // ------------------------------------------------------------------ selection & playback

    private fun select(r: RallyItem?, play: Boolean) {
        selected = r
        adapter.selected = r
        adapter.notifyDataSetChanged()
        editPanel.visibility = if (r == null) View.GONE else View.VISIBLE
        refresh()
        if (r != null && play) playRally(r)
    }

    private fun playRally(r: RallyItem) {
        setSequence(false)
        mode = Mode.SINGLE
        playing = r
        player.seekTo(r.startMs)
        player.play()
    }

    private fun stopPlayback() {
        if (mode != Mode.NONE) player.pause()
        mode = Mode.NONE
        setSequence(false)
    }

    private fun setSequence(on: Boolean) {
        playKept.text = if (on) "■ Stop" else "▶ Play kept"
        if (!on && mode == Mode.SEQUENCE) mode = Mode.NONE
    }

    private fun togglePlayKept() {
        if (mode == Mode.SEQUENCE) {
            player.pause()
            setSequence(false)
            return
        }
        val kept = session.rallies.filter { it.keep }
        if (kept.isEmpty()) {
            toast("No rallies are kept.")
            return
        }
        val pos = player.currentPosition
        val start = kept.firstOrNull { pos >= it.startMs && pos < it.endMs - 300 }
            ?: kept.firstOrNull { it.startMs > pos } ?: kept.first()
        mode = Mode.SEQUENCE
        setSequence(true)
        if (!(pos >= start.startMs && pos < start.endMs - 300)) player.seekTo(start.startMs)
        player.play()
    }

    private fun onTick() {
        val pos = player.currentPosition
        timeline.playheadMs = pos
        when (mode) {
            Mode.SINGLE -> {
                val r = playing
                if (r == null || !session.rallies.contains(r)) {
                    mode = Mode.NONE
                } else if (pos >= r.endMs) {
                    player.pause()
                    mode = Mode.NONE
                } else if (pos < r.startMs - 1500) {
                    mode = Mode.NONE
                }
            }
            Mode.SEQUENCE -> {
                if (!player.playWhenReady) return
                val kept = session.rallies.filter { it.keep }
                val cur = kept.firstOrNull { pos >= it.startMs - 300 && pos < it.endMs }
                if (cur == null) {
                    val next = kept.firstOrNull { it.startMs > pos }
                    if (next != null) {
                        player.seekTo(next.startMs)
                    } else {
                        player.pause()
                        setSequence(false)
                    }
                }
            }
            Mode.NONE -> {}
        }
    }

    // ------------------------------------------------------------------ editing

    private fun neighbours(r: RallyItem): Pair<Long, Long> {
        val sorted = session.rallies.sortedBy { it.startMs }
        val i = sorted.indexOf(r)
        val prevEnd = if (i > 0) sorted[i - 1].endMs else 0L
        val nextStart = if (i >= 0 && i < sorted.size - 1) sorted[i + 1].startMs else session.durationMs
        return Pair(prevEnd, nextStart)
    }

    private fun moveStart(deltaMs: Long) {
        val r = selected ?: return
        val (prevEnd, _) = neighbours(r)
        r.startMs = (r.startMs + deltaMs).coerceIn(prevEnd, maxOf(prevEnd, r.endMs - 500))
        afterEdit(r)
        player.seekTo(r.startMs)
        mode = Mode.SINGLE
        playing = r
        player.play()
    }

    private fun moveEnd(deltaMs: Long) {
        val r = selected ?: return
        val (_, nextStart) = neighbours(r)
        r.endMs = (r.endMs + deltaMs).coerceIn(minOf(nextStart, r.startMs + 500), nextStart)
        afterEdit(r)
        // replay the last couple of seconds so you can see the new end point
        player.seekTo(maxOf(r.startMs, r.endMs - 2500))
        mode = Mode.SINGLE
        playing = r
        player.play()
    }

    private fun splitAtPlayhead() {
        val r = selected ?: return
        val pos = player.currentPosition
        if (pos <= r.startMs + 500 || pos >= r.endMs - 500) {
            toast("Move the playhead inside this rally first (use the timeline or the player).")
            return
        }
        val second = RallyItem(pos, r.endMs, r.keep, 0, r.confidence, true)
        r.endMs = pos
        session.rallies.add(second)
        afterEdit(r)
        toast("Split into two rallies.")
    }

    private fun mergeWithNext() {
        val r = selected ?: return
        session.rallies.sortBy { it.startMs }
        val i = session.rallies.indexOf(r)
        if (i < 0 || i >= session.rallies.size - 1) {
            toast("This is the last rally.")
            return
        }
        val next = session.rallies[i + 1]
        r.endMs = maxOf(r.endMs, next.endMs)
        r.hits += next.hits
        r.keep = r.keep || next.keep
        session.rallies.removeAt(i + 1)
        afterEdit(r)
    }

    private fun deleteSelected() {
        val r = selected ?: return
        session.rallies.remove(r)
        if (playing === r) stopPlayback()
        select(null, false)
        afterEdit(null)
    }

    private fun addRallyAtPlayhead() {
        val pos = player.currentPosition
        session.rallies.firstOrNull { pos >= it.startMs && pos <= it.endMs }?.let {
            select(it, false)
            toast("The playhead is already inside rally ${session.rallies.indexOf(it) + 1}.")
            return
        }
        val nextStart = session.rallies.filter { it.startMs > pos }.minOfOrNull { it.startMs } ?: session.durationMs
        val end = minOf(pos + 8000, nextStart, session.durationMs)
        if (end - pos < 500) {
            toast("Not enough room here for a new rally.")
            return
        }
        val r = RallyItem(pos, end, true, 0, 0f, true)
        session.rallies.add(r)
        selected = r
        afterEdit(r)
        select(r, false)
        toast("Added. Use the Start/End buttons to adjust it.")
    }

    // ------------------------------------------------------------------ export

    private fun keptClips(): List<LongArray> {
        val clips = ArrayList<LongArray>()
        for (r in session.rallies.filter { it.keep }.sortedBy { it.startMs }) {
            val last = clips.lastOrNull()
            if (last != null && r.startMs <= last[1]) last[1] = maxOf(last[1], r.endMs)
            else clips.add(longArrayOf(r.startMs, r.endMs))
        }
        return clips
    }

    private fun showExport() {
        stopPlayback()
        val clips = keptClips()
        if (clips.isEmpty()) {
            toast("Keep at least one rally first.")
            return
        }
        val total = clips.sumOf { it[1] - it[0] }
        val shortSide = minOf(session.rawWidth, session.rawHeight)
        val labels = ArrayList<String>()
        val heights = ArrayList<Int?>()
        labels.add("Fast · original quality, no re-encoding (each clip may start up to 1 s early)")
        heights.add(-1)
        labels.add("Exact cuts · original resolution (slower)")
        heights.add(null)
        if (shortSide > 1080) {
            labels.add("Exact cuts · 1080p (smaller file)")
            heights.add(1080)
        }
        if (shortSide > 720) {
            labels.add("Exact cuts · 720p (smallest file)")
            heights.add(720)
        }
        var choice = 0
        MaterialAlertDialogBuilder(this)
            .setTitle("Export ${clips.size} rallies (${Fmt.clock(total)})")
            .setSingleChoiceItems(labels.toTypedArray(), 0) { _, which -> choice = which }
            .setPositiveButton("Export") { _, _ ->
                val h = heights[choice]
                if (h == -1) exportFast(clips, total) else exportExact(clips, total, h)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun outputName(): String {
        val base = session.name.substringBeforeLast('.').take(40)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "${base}_rallies_$stamp.mp4"
    }

    private class ProgressUi(val dialog: AlertDialog, val bar: LinearProgressIndicator, val text: TextView)

    private fun progressDialog(onCancel: () -> Unit): ProgressUi {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad / 2, pad, 0)
        val bar = LinearProgressIndicator(this)
        bar.max = 1000
        val text = TextView(this)
        text.setPadding(0, pad / 2, 0, 0)
        text.text = "Starting…"
        box.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(text)
        val d = MaterialAlertDialogBuilder(this)
            .setTitle("Exporting…")
            .setView(box)
            .setCancelable(false)
            .setNegativeButton("Cancel") { _, _ -> onCancel() }
            .show()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        return ProgressUi(d, bar, text)
    }

    private fun endProgress(ui: ProgressUi) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try {
            ui.dialog.dismiss()
        } catch (_: Exception) {
        }
    }

    private fun exportFast(clips: List<LongArray>, totalMs: Long) {
        val exporter = FastExporter(applicationContext)
        val ui = progressDialog { exporter.cancelled = true }
        val name = outputName()
        val app = applicationContext
        val uri = session.uri
        val rotation = session.rotation
        thread(name = "fast-export") {
            var item: Uri? = null
            try {
                val outItem = Gallery.createPending(app, name)
                item = outItem
                val pfd = app.contentResolver.openFileDescriptor(outItem, "rw")
                    ?: throw IllegalStateException("Could not open the output file")
                var lastPost = 0L
                pfd.use { p ->
                    exporter.export(uri, clips, rotation, p.fileDescriptor) { f ->
                        val now = SystemClock.uptimeMillis()
                        if (now - lastPost > 150 || f >= 1f) {
                            lastPost = now
                            main.post {
                                ui.bar.progress = (f * 1000).toInt()
                                ui.text.text = "${(f * 100).toInt()}%"
                            }
                        }
                    }
                }
                Gallery.publish(app, outItem)
                val size = Gallery.sizeOf(app, outItem)
                main.post {
                    endProgress(ui)
                    if (!isDestroyed) exported(outItem, clips.size, totalMs, size)
                }
            } catch (_: CancelledException) {
                item?.let { Gallery.discard(app, it) }
                main.post { endProgress(ui) }
            } catch (e: Exception) {
                item?.let { Gallery.discard(app, it) }
                main.post {
                    endProgress(ui)
                    if (!isDestroyed) {
                        MaterialAlertDialogBuilder(this)
                            .setTitle("Fast export didn't work")
                            .setMessage("${e.message ?: e.javaClass.simpleName}\n\nTry \"Exact cuts\" instead. It re-encodes the video, so it works with more formats.")
                            .setPositiveButton("OK", null)
                            .show()
                    }
                }
            }
        }
    }

    private fun exportExact(clips: List<LongArray>, totalMs: Long, targetShortSide: Int?) {
        val exporter = ExactExporter(this)
        var cancelled = false
        val ui = progressDialog {
            cancelled = true
            exporter.cancel()
        }
        val dispW = session.displayWidth
        val dispH = session.displayHeight
        val shortSide = minOf(dispW, dispH)
        val outHeight: Int? = targetShortSide?.let { t ->
            if (dispH <= dispW) t else ((t.toLong() * dispH / dispW) / 2 * 2).toInt()
        }
        val effShort = targetShortSide ?: shortSide
        val bitrate = when {
            effShort >= 2000 -> 40_000_000
            effShort >= 1000 -> 16_000_000
            else -> 8_000_000
        }
        val outFile = File(externalCacheDir ?: cacheDir, "rallycut_export.mp4")
        val name = outputName()
        val app = applicationContext
        val ticker = object : Runnable {
            override fun run() {
                if (cancelled) return
                val p = exporter.progress()
                ui.bar.progress = p * 10
                ui.text.text = "$p%"
                main.postDelayed(this, 300)
            }
        }
        main.post(ticker)
        try {
            exporter.start(session.uri, clips, outHeight, bitrate, outFile) { err ->
                main.removeCallbacks(ticker)
                if (cancelled) {
                    outFile.delete()
                    endProgress(ui)
                } else if (err != null) {
                    outFile.delete()
                    endProgress(ui)
                    MaterialAlertDialogBuilder(this)
                        .setTitle("Export failed")
                        .setMessage(err.message ?: err.javaClass.simpleName)
                        .setPositiveButton("OK", null)
                        .show()
                } else {
                    ui.text.text = "Saving to your gallery…"
                    thread(name = "copy-export") {
                        try {
                            val item = Gallery.copyIn(app, outFile, name)
                            val size = outFile.length()
                            outFile.delete()
                            main.post {
                                endProgress(ui)
                                if (!isDestroyed) exported(item, clips.size, totalMs, size)
                            }
                        } catch (e: Exception) {
                            outFile.delete()
                            main.post {
                                endProgress(ui)
                                toast("Couldn't save to the gallery: ${e.message}")
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            main.removeCallbacks(ticker)
            endProgress(ui)
            toast("Export failed: ${e.message}")
        }
    }

    private fun exported(item: Uri, count: Int, totalMs: Long, size: Long) {
        val msg = "Saved $count rallies (${Fmt.clock(totalMs)}, ${Fmt.size(size)}) to Movies/RallyCut.\n\n" +
                "The original video is ${Fmt.size(session.sizeBytes)}. Delete it to free up space?"
        MaterialAlertDialogBuilder(this)
            .setTitle("Export finished")
            .setMessage(msg)
            .setPositiveButton("Delete original") { _, _ -> confirmDeleteOriginal() }
            .setNegativeButton("Keep original", null)
            .setNeutralButton("Watch") { _, _ ->
                try {
                    startActivity(
                        Intent(Intent.ACTION_VIEW).setDataAndType(item, "video/mp4")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    )
                } catch (_: Exception) {
                    toast("No video player found.")
                }
            }
            .show()
    }

    private fun confirmDeleteOriginal() {
        val uri = session.uri
        if (Build.VERSION.SDK_INT >= 30) {
            val mediaUri: Uri? = try {
                if (uri.authority == MediaStore.AUTHORITY) uri else MediaStore.getMediaUri(this, uri)
            } catch (_: Exception) {
                null
            }
            if (mediaUri != null) {
                try {
                    val pi = MediaStore.createDeleteRequest(contentResolver, listOf(mediaUri))
                    deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                    return
                } catch (_: Exception) {
                }
            }
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete the original video?")
            .setMessage("${session.name} (${Fmt.size(session.sizeBytes)}) will be deleted. This can't be undone.")
            .setPositiveButton("Delete") { _, _ ->
                val ok = try {
                    DocumentsContract.deleteDocument(contentResolver, uri)
                } catch (_: Exception) {
                    false
                }
                if (ok) originalDeleted() else toast("Couldn't delete it from here. Please delete it in your Gallery.")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun originalDeleted() {
        toast("Original video deleted.")
        SessionStore.delete(this, session.key)
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
        finish()
    }
}

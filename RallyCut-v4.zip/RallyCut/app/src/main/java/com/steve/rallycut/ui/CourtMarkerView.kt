package com.steve.rallycut.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.steve.rallycut.core.PlayArea
import kotlin.math.hypot

/**
 * Shows a video frame with 4 freely draggable corner handles. Any 4-sided shape is allowed, so the
 * play area can be marked from any camera angle.
 */
class CourtMarkerView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    var bitmap: Bitmap? = null
        set(value) {
            field = value
            invalidate()
        }

    /** x0,y0..x3,y3 normalised 0..1 in the frame; any order. */
    val handles = DEFAULT.copyOf()

    var onChanged: (() -> Unit)? = null

    private val dp = resources.displayMetrics.density
    private val imgRect = RectF()
    private var drag = -1
    private var grabDx = 0f
    private var grabDy = 0f

    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(50, 255, 235, 59)
        style = Paint.Style.FILL
    }
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 235, 59)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * dp
    }
    private val handleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(110, 255, 235, 59)
        style = Paint.Style.FILL
    }
    private val handleRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2f * dp
    }
    private val loupeRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 3f * dp
    }
    private val crossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 82, 82)
        strokeWidth = 1.5f * dp
    }
    private val badPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 82, 82)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * dp
    }
    private val bgPaint = Paint().apply { color = Color.BLACK }

    fun setHandles(h: FloatArray) {
        for (i in 0 until 8) handles[i] = h[i].coerceIn(0f, 1f)
        invalidate()
    }

    /** Corners in order around the shape, or null if the shape is invalid (sides crossing). */
    fun ordered(): FloatArray? = PlayArea.orderAround(handles)

    private fun computeRect() {
        val b = bitmap
        val pad = 18 * dp
        val w = width - 2 * pad
        val h = height - 2 * pad
        if (b == null || w <= 0 || h <= 0) {
            imgRect.set(pad, pad, pad + w.coerceAtLeast(1f), pad + h.coerceAtLeast(1f))
            return
        }
        val s = minOf(w / b.width, h / b.height)
        val dw = b.width * s
        val dh = b.height * s
        val l = pad + (w - dw) / 2
        val t = pad + (h - dh) / 2
        imgRect.set(l, t, l + dw, t + dh)
    }

    private fun vx(nx: Double) = (imgRect.left + nx * imgRect.width()).toFloat()
    private fun vy(ny: Double) = (imgRect.top + ny * imgRect.height()).toFloat()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        computeRect()
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        drawScene(canvas)
        for (i in 0 until 4) {
            val x = vx(handles[2 * i].toDouble())
            val y = vy(handles[2 * i + 1].toDouble())
            canvas.drawCircle(x, y, 13 * dp, handleFill)
            canvas.drawCircle(x, y, 13 * dp, handleRing)
        }
        if (drag >= 0) drawLoupe(canvas)
    }

    private fun drawScene(canvas: Canvas) {
        bitmap?.let { canvas.drawBitmap(it, null, imgRect, bmpPaint) }
        val q = ordered()
        if (q == null) {
            // not a valid court shape: just connect the handles in their current order, in red
            val p = Path()
            for (i in 0 until 4) {
                val x = vx(handles[2 * i].toDouble())
                val y = vy(handles[2 * i + 1].toDouble())
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            p.close()
            canvas.drawPath(p, badPaint)
            return
        }
        val path = Path()
        for (i in 0 until 4) {
            val x = vx(q[2 * i].toDouble())
            val y = vy(q[2 * i + 1].toDouble())
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, edgePaint)
    }

    private fun drawLoupe(canvas: Canvas) {
        val hx = vx(handles[2 * drag].toDouble())
        val hy = vy(handles[2 * drag + 1].toDouble())
        val r = 62 * dp
        val zoom = 2.5f
        // put the magnifier in the top corner away from the finger
        val cx = if (hx > width / 2f) r + 10 * dp else width - r - 10 * dp
        val cy = r + 10 * dp
        val clip = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
        canvas.save()
        canvas.clipPath(clip)
        canvas.drawRect(cx - r, cy - r, cx + r, cy + r, bgPaint)
        canvas.translate(cx, cy)
        canvas.scale(zoom, zoom)
        canvas.translate(-hx, -hy)
        drawScene(canvas)
        canvas.restore()
        canvas.drawCircle(cx, cy, r, loupeRing)
        canvas.drawLine(cx - 10 * dp, cy, cx + 10 * dp, cy, crossPaint)
        canvas.drawLine(cx, cy - 10 * dp, cx, cy + 10 * dp, crossPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        computeRect()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                var best = -1
                var bestD = 56 * dp
                for (i in 0 until 4) {
                    val d = hypot(e.x - vx(handles[2 * i].toDouble()), e.y - vy(handles[2 * i + 1].toDouble()))
                    if (d < bestD) {
                        bestD = d
                        best = i
                    }
                }
                drag = best
                if (drag >= 0) {
                    grabDx = vx(handles[2 * drag].toDouble()) - e.x
                    grabDy = vy(handles[2 * drag + 1].toDouble()) - e.y
                    parent?.requestDisallowInterceptTouchEvent(true)
                    invalidate()
                }
                return drag >= 0
            }
            MotionEvent.ACTION_MOVE -> {
                if (drag < 0) return false
                val nx = ((e.x + grabDx - imgRect.left) / imgRect.width()).coerceIn(0f, 1f)
                val ny = ((e.y + grabDy - imgRect.top) / imgRect.height()).coerceIn(0f, 1f)
                handles[2 * drag] = nx
                handles[2 * drag + 1] = ny
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (drag >= 0) {
                    drag = -1
                    invalidate()
                    onChanged?.invoke()
                    if (e.actionMasked == MotionEvent.ACTION_UP) performClick()
                }
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    companion object {
        /** A wide box in the middle of the picture, where players usually are. */
        val DEFAULT = floatArrayOf(0.05f, 0.35f, 0.95f, 0.35f, 0.95f, 0.90f, 0.05f, 0.90f)
    }
}

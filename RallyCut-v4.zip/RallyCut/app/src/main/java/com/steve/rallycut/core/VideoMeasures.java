package com.steve.rallycut.core;

import java.util.ArrayDeque;

/**
 * Per-frame movement measurements at 10 frames a second, streamed:
 *  mov  = share of play-area cells that changed since the previous frame,
 *  step = how much the players' silhouettes changed since the previous frame,
 *  net  = how different the silhouettes are 1.5 s before vs 1.5 s after (walking somewhere = big,
 *         moving back and forth in a rally = small).
 * Silhouettes come from a background picture: the per-cell median of one sample a second within +-30 s,
 * so players who stand still for a few seconds still count as players.
 */
public final class VideoMeasures {
    public static final double FPS = 10.0;
    static final int PER_SEC = 10;
    static final double FG_THR = 18.0, MOVE_THR = 12.0;
    static final int BG_HALF = 30, NET_H = 15, BINS = 64;

    private final int gw, gh, n;
    private final boolean[] mask;
    private final int maskCount;

    // histogram of quantised samples (value/4) per cell, over the current window of 1-per-second samples
    private final short[] hist;
    private final ArrayDeque<byte[]> samples = new ArrayDeque<>(); // samples in window, oldest first
    private int firstSample = 0;   // index of samples.peekFirst()
    private int sampleCount = 0;   // samples received so far
    private final float[] bg;
    private int bgFor = -1;        // second index the background was computed for

    private final ArrayDeque<float[]> pending = new ArrayDeque<>(); // grids waiting for their background
    private int nextFg = 0;        // index of the next frame to turn into a silhouette
    private int received = 0;
    private float[] prevGrid;

    private float[] prevFgb;
    private final ArrayDeque<float[]> fgbRing = new ArrayDeque<>(); // silhouettes nextFg-31 .. nextFg-1

    private float[] mov = new float[4096], step = new float[4096], net = new float[4096];
    private int netDone = 0;

    public VideoMeasures(int gw, int gh, boolean[] mask) {
        this.gw = gw;
        this.gh = gh;
        this.n = gw * gh;
        this.mask = mask;
        int c = 0;
        for (boolean b : mask) if (b) c++;
        maskCount = Math.max(1, c);
        hist = new short[n * BINS];
        bg = new float[n];
    }

    /** Next frame (cell means 0..255, row-major gw x gh). Frames must arrive at 10 a second. */
    public void push(float[] grid) {
        int i = received++;
        ensure(i + 1);
        if (i > 0) {
            int moving = 0;
            for (int k = 0; k < n; k++) if (mask[k] && Math.abs(grid[k] - prevGrid[k]) > MOVE_THR) moving++;
            mov[i] = moving / (float) maskCount;
            if (i == 1) mov[0] = mov[1];
        }
        prevGrid = grid;
        if (i % PER_SEC == 0) {
            byte[] q = new byte[n];
            for (int k = 0; k < n; k++) q[k] = (byte) quant(grid[k]);
            samples.addLast(q);
            for (int k = 0; k < n; k++) hist[k * BINS + q[k]]++;
            sampleCount++;
        }
        pending.addLast(grid);
        // a frame's background needs samples up to (its second + 30)
        while (!pending.isEmpty() && sampleCount > (nextFg / PER_SEC) + BG_HALF) processNext(false);
    }

    private static int quant(float v) {
        int q = (int) Math.floor(v / 4.0);
        return q < 0 ? 0 : (q >= BINS ? BINS - 1 : q);
    }

    private void processNext(boolean end) {
        float[] g = pending.pollFirst();
        int i = nextFg++;
        int si = i / PER_SEC;
        if (si != bgFor) {
            // slide the sample window to [si-30, si+30]
            while (firstSample < si - BG_HALF && !samples.isEmpty()) {
                byte[] old = samples.pollFirst();
                for (int k = 0; k < n; k++) hist[k * BINS + old[k]]--;
                firstSample++;
            }
            int cnt = samples.size();
            int kth = (cnt - 1) / 2;
            for (int k = 0; k < n; k++) {
                int acc = 0, base = k * BINS, b = 0;
                for (; b < BINS; b++) {
                    acc += hist[base + b];
                    if (acc > kth) break;
                }
                bg[k] = Math.min(b, BINS - 1) * 4f + 2f;
            }
            bgFor = si;
        }
        float[] fg = new float[n];
        for (int k = 0; k < n; k++) fg[k] = Math.abs(g[k] - bg[k]) > FG_THR ? 1f : 0f;
        float[] fgb = box3(fg);
        if (i > 0) {
            double s = 0;
            for (int k = 0; k < n; k++) if (mask[k]) s += Math.abs(fgb[k] - prevFgb[k]);
            step[i] = (float) (s / maskCount);
            if (i == 1) step[0] = step[1];
        }
        prevFgb = fgb;
        fgbRing.addLast(fgb);
        if (fgbRing.size() > 2 * NET_H + 1) fgbRing.pollFirst();
        // net for frame j = i - 15: silhouettes at max(0, j-15) and i
        int j = i - NET_H;
        if (j >= 0) {
            net[j] = diff(oldestFor(j), fgb);
            netDone = j + 1;
        }
    }

    /** Silhouette of frame max(0, j - 15), still in the ring. */
    private float[] oldestFor(int j) {
        int want = Math.max(0, j - NET_H);
        int firstInRing = nextFg - fgbRing.size();
        int skip = want - firstInRing;
        java.util.Iterator<float[]> it = fgbRing.iterator();
        float[] f = it.next();
        for (int s = 0; s < skip; s++) f = it.next();
        return f;
    }

    private float diff(float[] a, float[] b) {
        double s = 0;
        for (int k = 0; k < n; k++) if (mask[k]) s += Math.abs(a[k] - b[k]);
        return (float) (s / maskCount);
    }

    private float[] box3(float[] f) {
        float[] o = new float[n];
        for (int r = 0; r < gh; r++) {
            int r0 = Math.max(0, r - 1), r2 = Math.min(gh - 1, r + 1);
            for (int c = 0; c < gw; c++) {
                int c0 = Math.max(0, c - 1), c2 = Math.min(gw - 1, c + 1);
                // edge cells repeat themselves (like numpy 'edge' padding)
                float s = 0;
                int[] rr = {r0, r, r2}, cc = {c0, c, c2};
                for (int a = 0; a < 3; a++) {
                    int base = rr[a] * gw;
                    for (int b = 0; b < 3; b++) s += f[base + cc[b]];
                }
                o[r * gw + c] = s / 9f;
            }
        }
        return o;
    }

    private void ensure(int size) {
        if (size > mov.length) {
            int ns = Math.max(size, mov.length * 2);
            mov = java.util.Arrays.copyOf(mov, ns);
            step = java.util.Arrays.copyOf(step, ns);
            net = java.util.Arrays.copyOf(net, ns);
        }
    }

    /** Call once after the last frame. */
    public void finish() {
        while (!pending.isEmpty()) processNext(true);
        int T = received;
        if (T == 1) {
            mov[0] = 0;
            step[0] = 0;
        }
        // remaining nets use the last silhouette
        for (int j = netDone; j < T; j++) net[j] = diff(oldestFor(j), prevFgb);
    }

    public int frames() {
        return received;
    }

    public float[] mov() {
        return java.util.Arrays.copyOf(mov, received);
    }

    public float[] step() {
        return java.util.Arrays.copyOf(step, received);
    }

    public float[] net() {
        return java.util.Arrays.copyOf(net, received);
    }
}

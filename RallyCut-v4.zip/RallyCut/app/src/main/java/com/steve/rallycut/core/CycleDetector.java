package com.steve.rallycut.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Finds rallies from the badminton "cycle": everyone stands still for the serve (SETUP), the rally is
 * played (RALLY), then players scatter, fetch the shuttle and walk back (BREAK), and it repeats.
 * A Viterbi pass picks the most likely SETUP/RALLY/BREAK sequence (with minimum lengths), then hit
 * sounds pin down where each rally starts and ends.
 */
public final class CycleDetector {
    static final double FPS = VideoMeasures.FPS;

    private CycleDetector() {
    }

    public static final class Rally {
        public final double start, end;
        public final int hits;
        public final double confidence;

        Rally(double start, double end, int hits, double confidence) {
            this.start = start;
            this.end = end;
            this.hits = hits;
            this.confidence = confidence;
        }
    }

    public static final class Result {
        public final List<Rally> rallies;
        /** Rally likelihood 0..1 per frame (10 a second), for drawing; empty without video. */
        public final float[] activity;

        Result(List<Rally> rallies, float[] activity) {
            this.rallies = rallies;
            this.activity = activity;
        }
    }

    // ------------------------------------------------------------------ helpers (mirror numpy)

    static double[] smooth(double[] x, int h) {
        int n = x.length;
        double[] pre = new double[n + 1];
        for (int i = 0; i < n; i++) pre[i + 1] = pre[i] + x[i];
        double[] o = new double[n];
        for (int i = 0; i < n; i++) {
            int a = Math.max(0, i - h), b = Math.min(n, i + h + 1);
            o[i] = (pre[b] - pre[a]) / (b - a);
        }
        return o;
    }

    static double pct(double[] v, double p) {
        double[] s = v.clone();
        Arrays.sort(s);
        return s[(int) (p * (s.length - 1))];
    }

    static double[] rz(double[] v) {
        double med = pct(v, 0.5), iqr = pct(v, 0.75) - pct(v, 0.25);
        double[] o = new double[v.length];
        for (int i = 0; i < v.length; i++) o[i] = (v[i] - med) / (iqr + 1e-9);
        return o;
    }

    static double[] toD(float[] f) {
        double[] d = new double[f.length];
        for (int i = 0; i < f.length; i++) d[i] = f[i];
        return d;
    }

    // ------------------------------------------------------------------ main entry

    /**
     * mov/step/net: per-frame video measurements (may be empty if the video couldn't be read);
     * hits: hit-sound times in seconds; sensitivity 0..1 (higher = more rallies).
     */
    public static Result detect(float[] mov, float[] step, float[] net, float[] hits, double duration, double sensitivity) {
        float[] sortedHits = hits.clone();
        Arrays.sort(sortedHits);
        int T = mov.length;
        if (T < 40) return new Result(audioOnly(sortedHits, duration), new float[0]);

        double[] M = toD(mov), St = toD(step), N = toD(net);
        // --- features
        double q05 = pct(M, 0.05), q90 = pct(M, 0.90);
        double span = Math.max(q90 - q05, 1e-6);
        double[] x = new double[T], x2 = new double[T];
        for (int i = 0; i < T; i++) {
            x[i] = (M[i] - q05) / span;
            x2[i] = x[i] * x[i];
        }
        double[] mx = smooth(x, 5), mx2 = smooth(x2, 5), std1 = new double[T];
        for (int i = 0; i < T; i++) std1[i] = Math.sqrt(Math.max(mx2[i] - mx[i] * mx[i], 0));
        double[] path = smooth(St, VideoMeasures.NET_H);
        double[] ratio = new double[T];
        for (int i = 0; i < T; i++) {
            path[i] *= (2 * VideoMeasures.NET_H + 1);
            ratio[i] = N[i] / (path[i] + 1e-3);
        }
        double[] h = new double[T];
        for (float t : sortedHits) {
            int i = (int) (t * FPS);
            if (i >= 0 && i < T) h[i] += 1;
        }
        double[] hd = smooth(h, 12);
        for (int i = 0; i < T; i++) hd[i] *= 25;
        boolean audioOk = sortedHits.length >= 4 * duration / 60.0;
        double[] zp = rz(path), zs = rz(std1), zr = rz(ratio), zh = rz(hd);
        double[] score = new double[T];
        for (int i = 0; i < T; i++) {
            double s = zp[i] + zs[i] - zr[i];
            score[i] = audioOk ? s + zh[i] : s * (4.0 / 3.0);
        }
        double[] still = smooth(St, 4);

        // --- decode
        double c = 1.0 - sensitivity;
        double[] r = new double[T];
        List<double[]> segs = decode(score, still, c, r);

        // --- refine with hit sounds
        List<Rally> out = new ArrayList<>();
        for (double[] sg : segs) {
            double s0 = sg[0], s1 = sg[1];
            double st = s0 - 0.3, en = s1 + 1.0;
            int nh = 0;
            if (audioOk) {
                List<Float> hs = new ArrayList<>();
                for (float t : sortedHits) if (t >= s0 - 0.5 && t <= s1 + 0.5) hs.add(t);
                nh = hs.size();
                if (hs.size() >= 2) {
                    double first = hs.get(0);
                    st = first <= s0 + 4 ? Math.max(s0 - 0.3, first - 1.0) : s0 - 0.3;
                    double end = hs.get(0);
                    for (int k = 1; k < hs.size(); k++) {
                        double t = hs.get(k), g = t - end;
                        if (g <= 2.5 || (g <= 4.0 && meanR(r, end, t) >= 0.5)) end = t;
                        else break;
                    }
                    en = Math.min(s1 + 1.0, end + 1.2);
                    if (en - st < 2.0) {
                        st = s0 - 0.3;
                        en = s1 + 1.0;
                    }
                }
            }
            st = Math.max(0.0, st);
            en = Math.min(duration, en);
            double conf = meanR(r, st, en);
            out.add(new Rally(st, en, nh, conf));
        }
        float[] act = new float[T];
        for (int i = 0; i < T; i++) act[i] = (float) r[i];
        return new Result(out, act);
    }

    static double meanR(double[] r, double a, double b) {
        int i0 = (int) (a * FPS);
        int i1 = Math.max(i0 + 1, (int) (b * FPS));
        i0 = Math.max(0, Math.min(i0, r.length - 1));
        i1 = Math.max(i0 + 1, Math.min(i1, r.length));
        double s = 0;
        for (int i = i0; i < i1; i++) s += r[i];
        return s / (i1 - i0);
    }

    /** Viterbi over SETUP -> RALLY -> BREAK -> SETUP with minimum durations. Fills r. Returns rally segments (s). */
    static List<double[]> decode(double[] score, double[] still, double c, double[] r) {
        final double k = 0.8, stillW = 0.35, pBR = 4.0, pSB = 3.0, eps = 1e-4;
        final int sMin = 6, rMin = 20, bMin = 25;
        int T = score.length;
        double ref = Math.log(pct(still, 0.2) + 1e-6);
        double[] lS = new double[T], lR = new double[T], lB = new double[T];
        for (int t = 0; t < T; t++) {
            r[t] = 1 / (1 + Math.exp(-k * (score[t] - c)));
            double s = 1 / (1 + Math.exp(-(ref - Math.log(still[t] + 1e-6)) / stillW));
            lR[t] = Math.log(r[t] + eps);
            lB[t] = Math.log(1 - r[t] + eps) + Math.log(1 - s + eps);
            lS[t] = Math.log(1 - r[t] + eps) + Math.log(s + eps);
        }
        int N = sMin + rMin + bMin;
        int[] kind = new int[N];
        for (int j = 0; j < N; j++) kind[j] = j < sMin ? 0 : (j < sMin + rMin ? 1 : 2);
        int sS = 0, sR = sMin, sB = sMin + rMin;
        int lastS = sMin - 1, lastR = sMin + rMin - 1, lastB = N - 1;
        final double NEG = -1e18;
        double[] V = new double[N];
        Arrays.fill(V, NEG);
        V[lastS] = 0;
        V[lastR] = 0;
        V[lastB] = 0;
        for (int j = 0; j < N; j++) V[j] += em(kind[j], lS, lR, lB, 0);
        int[][] bp = new int[T][];
        double[] nv = new double[N];
        for (int t = 1; t < T; t++) {
            int[] b = new int[N];
            for (int j = 0; j < N; j++) {
                double best = NEG;
                int arg = -1;
                if (j != sS && j != sR && j != sB) {
                    best = V[j - 1];
                    arg = j - 1;
                }
                if ((j == lastS || j == lastR || j == lastB) && V[j] > best) {
                    best = V[j];
                    arg = j;
                }
                if (j == sR) {
                    if (V[lastS] > best) {
                        best = V[lastS];
                        arg = lastS;
                    }
                    if (V[lastB] - pBR > best) {
                        best = V[lastB] - pBR;
                        arg = lastB;
                    }
                }
                if (j == sB) {
                    if (V[lastR] > best) {
                        best = V[lastR];
                        arg = lastR;
                    }
                    if (V[lastS] - pSB > best) {
                        best = V[lastS] - pSB;
                        arg = lastS;
                    }
                }
                if (j == sS) {
                    if (V[lastB] > best) {
                        best = V[lastB];
                        arg = lastB;
                    }
                }
                nv[j] = best;
                b[j] = arg;
            }
            for (int j = 0; j < N; j++) V[j] = nv[j] + em(kind[j], lS, lR, lB, t);
            bp[t] = b;
        }
        int st = 0;
        for (int j = 1; j < N; j++) if (V[j] > V[st]) st = j;
        int[] lab = new int[T];
        for (int t = T - 1; t >= 0; t--) {
            lab[t] = kind[st];
            if (t > 0) st = bp[t][st];
        }
        List<double[]> segs = new ArrayList<>();
        int i = 0;
        while (i < T) {
            if (lab[i] == 1) {
                int j = i;
                while (j + 1 < T && lab[j + 1] == 1) j++;
                segs.add(new double[]{i / FPS, (j + 1) / FPS});
                i = j + 1;
            } else {
                i++;
            }
        }
        return segs;
    }

    private static double em(int kind, double[] lS, double[] lR, double[] lB, int t) {
        return kind == 0 ? lS[t] : (kind == 1 ? lR[t] : lB[t]);
    }

    /** No usable video: chain hit sounds (gaps up to 2.5 s, at least 3 hits). */
    static List<Rally> audioOnly(float[] hits, double duration) {
        List<Rally> out = new ArrayList<>();
        int i = 0;
        while (i < hits.length) {
            int j = i;
            while (j + 1 < hits.length && hits[j + 1] - hits[j] <= 2.5) j++;
            if (j - i + 1 >= 3) {
                out.add(new Rally(Math.max(0, hits[i] - 1.0), Math.min(duration, hits[j] + 1.2), j - i + 1, 0.5));
            }
            i = j + 1;
        }
        return out;
    }
}

package com.steve.rallycut.core;

/**
 * The analysis grid: the bounding box of the user's play-area shape, split into roughly square cells
 * (at most ~96 along the longer side). Cells whose centre lies inside the shape are "in the zone".
 * Each cell value is the mean of S x S sample points.
 */
public final class PlayArea {
    public static final int S = 4;

    public final int gw, gh;
    public final double x0, y0, cell;
    public final boolean[] mask;
    /** Sample positions in display pixels: column c uses sx[c*S .. c*S+S-1], row r uses sy[r*S ..]. */
    public final int[] sx, sy;

    /** poly: 4 corners in display pixels (convex, in order around the shape). */
    public PlayArea(float[] poly, int dispW, int dispH, int maxCells) {
        double minX = 1e18, maxX = -1e18, minY = 1e18, maxY = -1e18;
        for (int i = 0; i < 4; i++) {
            minX = Math.min(minX, poly[2 * i]);
            maxX = Math.max(maxX, poly[2 * i]);
            minY = Math.min(minY, poly[2 * i + 1]);
            maxY = Math.max(maxY, poly[2 * i + 1]);
        }
        double bx0 = Math.max(0, minX), bx1 = Math.min(dispW, maxX);
        double by0 = Math.max(0, minY), by1 = Math.min(dispH, maxY);
        if (bx1 - bx0 < 8) {
            bx0 = 0;
            bx1 = dispW;
        }
        if (by1 - by0 < 8) {
            by0 = 0;
            by1 = dispH;
        }
        double c = Math.max(Math.max(bx1 - bx0, by1 - by0) / maxCells, 1.0);
        gw = Math.max(4, (int) ((bx1 - bx0) / c));
        gh = Math.max(4, (int) ((by1 - by0) / c));
        x0 = bx0;
        y0 = by0;
        cell = c;
        mask = new boolean[gw * gh];
        for (int r = 0; r < gh; r++) {
            double py = y0 + (r + 0.5) * c;
            for (int col = 0; col < gw; col++) {
                double px = x0 + (col + 0.5) * c;
                mask[r * gw + col] = inside(poly, px, py);
            }
        }
        sx = new int[gw * S];
        sy = new int[gh * S];
        for (int col = 0; col < gw; col++) {
            for (int j = 0; j < S; j++) {
                sx[col * S + j] = clamp((int) (x0 + (col + (j + 0.5) / S) * c), 0, dispW - 1);
            }
        }
        for (int r = 0; r < gh; r++) {
            for (int j = 0; j < S; j++) {
                sy[r * S + j] = clamp((int) (y0 + (r + (j + 0.5) / S) * c), 0, dispH - 1);
            }
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    /** Even-odd point-in-polygon test. */
    static boolean inside(float[] p, double x, double y) {
        boolean in = false;
        int n = p.length / 2;
        for (int i = 0, j = n - 1; i < n; j = i++) {
            double xi = p[2 * i], yi = p[2 * i + 1], xj = p[2 * j], yj = p[2 * j + 1];
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) in = !in;
        }
        return in;
    }

    /**
     * Puts 4 freely placed points in order around their centre (so the shape doesn't cross itself).
     * Returns null if the 4 points don't form a convex 4-sided shape.
     */
    public static float[] orderAround(float[] pts) {
        double cx = 0, cy = 0;
        for (int i = 0; i < 4; i++) {
            cx += pts[2 * i];
            cy += pts[2 * i + 1];
        }
        final double fcx = cx / 4, fcy = cy / 4;
        Integer[] idx = {0, 1, 2, 3};
        java.util.Arrays.sort(idx, (a, b) -> Double.compare(
                Math.atan2(pts[2 * a + 1] - fcy, pts[2 * a] - fcx),
                Math.atan2(pts[2 * b + 1] - fcy, pts[2 * b] - fcx)));
        float[] s = new float[8];
        for (int i = 0; i < 4; i++) {
            s[2 * i] = pts[2 * idx[i]];
            s[2 * i + 1] = pts[2 * idx[i] + 1];
        }
        int sign = 0;
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4, k = (i + 2) % 4;
            double ux = s[2 * j] - s[2 * i], uy = s[2 * j + 1] - s[2 * i + 1];
            double vx = s[2 * k] - s[2 * j], vy = s[2 * k + 1] - s[2 * j + 1];
            double cr = ux * vy - uy * vx;
            int sg = cr > 1e-9 ? 1 : (cr < -1e-9 ? -1 : 0);
            if (sg == 0) return null;
            if (sign == 0) sign = sg;
            else if (sg != sign) return null;
        }
        return s;
    }
}

package com.steve.rallycut.core;

/**
 * Streaming loudness of the high band (above 2 kHz, where the "thwack" of a shuttle hit lives),
 * one dB value per hop (2.5 ms). Feed mono samples in -1..1.
 */
public final class AudioEnvelope {
    public static final double HOP = 0.0025;

    private final int hop;
    private final double b0, b1, b2, a1, a2;
    private double z1, z2;
    private double sum;
    private int count;
    private float[] env = new float[1 << 16];
    private int size;

    public AudioEnvelope(int sampleRate) {
        hop = Math.max(1, (int) Math.round(sampleRate * HOP));
        double w0 = 2 * Math.PI * 2000.0 / sampleRate, q = 0.7071;
        double al = Math.sin(w0) / (2 * q), cs = Math.cos(w0);
        double a0 = 1 + al;
        b0 = (1 + cs) / 2 / a0;
        b1 = -(1 + cs) / a0;
        b2 = (1 + cs) / 2 / a0;
        a1 = -2 * cs / a0;
        a2 = (1 - al) / a0;
    }

    public void push(double x) {
        // transposed direct form II (same output as scipy.signal.lfilter)
        double y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        sum += y * y;
        if (++count == hop) {
            if (size == env.length) env = java.util.Arrays.copyOf(env, size * 2);
            env[size++] = (float) (10 * Math.log10(sum / hop + 1e-12));
            sum = 0;
            count = 0;
        }
    }

    public float[] result() {
        return java.util.Arrays.copyOf(env, size);
    }

    /**
     * Shuttle hits: the high band jumps at least 9 dB above the previous ~25 ms within one 2.5 ms step,
     * and it is the loudest point within +-20 ms. Returns hit times in seconds.
     */
    public static float[] onsets(float[] e) {
        int n = e.length;
        float[] out = new float[256];
        int m = 0;
        float[] pre = new float[10];
        int k = 12;
        while (k < n - 8) {
            System.arraycopy(e, k - 12, pre, 0, 10);
            java.util.Arrays.sort(pre);
            double med = (pre[4] + pre[5]) / 2.0;
            if (e[k] - med >= 9.0) {
                boolean peak = true;
                for (int j = k - 8; j <= k + 8; j++) {
                    if (e[j] > e[k]) {
                        peak = false;
                        break;
                    }
                }
                if (peak) {
                    if (m == out.length) out = java.util.Arrays.copyOf(out, m * 2);
                    out[m++] = (float) (k * HOP);
                    k += 40; // 100 ms refractory
                    continue;
                }
            }
            k++;
        }
        return java.util.Arrays.copyOf(out, m);
    }
}
